# Air Carrier Path C: build in Advana FM with copy and paste only

No file upload and no import. Everything moves by copying text from this kit and pasting it into one Advana notebook.
Tested end to end on 2026-11-12 in the commercial workspace (build into a `zzpk_` test prefix): ALL CHECKS PASSED.

## What you end up with
* 77 Air Carrier tables, 2,005,448 rows, identical to the source (row counts and full-content diffs checked)
* 36 views, 8 SQL functions, 18 CHECK constraints
* 552 source files (bundle, MCP servers, notebooks, DDL, docs) with the old catalog/schema/paths rewritten to yours
* 3 Genie Code skills installed for you

## What you do not get
* PDFs and ship photos (the volume stays empty). Page text is still there in `aircarrier_pdf_pages`, but the document viewer, `parse_pdf`, and re-running PDF extraction need the PDF files.
* The web app, MCP servers, and jobs are not deployed. Their code is extracted, so you can deploy them later if Advana allows Apps (phases 4 to 6 of `02_ADVANA_GENIE_CODE_SETUP_PROMPT.md`).
* Grants are not applied (the app service principal does not exist in Advana).
* MCP A Creator trace tables are skipped (not part of Air Carrier).

## Kit contents
* `01_CELL1_SETUP.py`: Cell 1. You edit three values.
* `chunks/01_code-01.py` to `chunks/46_pdf-27.py`: 46 files, each pasted into Cell 2 in turn.
  * 01 to 10 = code (required)
  * 11 to 19 = core data (required)
  * 20 to 46 = PDF text stores (optional: `pdf_pages`, `pdf_tables`, `pdf_cells`)
* `03_CELL3_BUILD.py`: Cell 3. Builds everything and verifies it.

Time: about 1 to 1.5 hours of pasting for all 46 chunks (about 25 minutes for the 19 required), plus about 7 minutes of build.

---

## Step 0: Check that paste works (2 minutes)
1. Open Advana FM in one browser tab and this workspace in another, on the same computer.
2. In Advana, create a scratch notebook and paste any sentence copied from this file.
   * If it pastes, continue.
   * If paste is blocked (some VDI setups block it), Path C cannot work. Use Path A: an approved transfer of `aircarrier_package_COMPLETE.zip`.

## Step 1: Get the kit onto your computer (5 minutes)
1. In this workspace, go to `package` and right-click the `paste_kit` folder. Choose Export, then Source file. A zip downloads.
2. Unzip it. You will open each file in Notepad (or another plain text editor).
   * If downloads are blocked too, open each file here in the workspace instead, click into the text, press Ctrl+A, then Ctrl+C.

## Step 2: Create the Advana notebook
1. In Advana: Workspace, then your home folder, then Create, then Notebook. Name it `Air Carrier Paste Kit`, language Python.
2. Attach serverless compute, or a Unity Catalog cluster on DBR 13.3 or later. Writing to `/Workspace` and `/Volumes` from Python needs it.
3. You need these rights in Advana on the target catalog: USE CATALOG, CREATE SCHEMA (or an existing schema you own), CREATE TABLE, CREATE VOLUME, CREATE FUNCTION.

## Step 3: Cell 1 (setup)
1. Open `01_CELL1_SETUP.py`, then Ctrl+A, Ctrl+C. Paste it into Cell 1.
2. Edit the three `CHANGE_ME` lines:
   * `CATALOG = "..."`: an Advana catalog you can create in
   * `SCHEMA = "..."`: for example `aircarrier` (created if missing)
   * `CODE_DIR = "/Workspace/Users/<your Advana email>/aircarrier"`
3. Leave `NAME_PREFIX = ""`.
4. Press Shift+Enter. Expected output:
   ```
   Setup OK. Pasted chunks are saved in ...
     code   0/10  next: code-01
     core   0/9  next: core-01
     pdf    0/27  next: pdf-01
   ```

## Step 4: Cell 2 (paste the chunks, one at a time)
1. Add an empty cell below Cell 1. This is Cell 2. You reuse it for every chunk.
2. For each file `chunks/01_code-01.py`, `02_code-02.py`, ... in number order:
   1. Open the file in Notepad, then Ctrl+A, Ctrl+C.
   2. Click into Cell 2, then Ctrl+A, Ctrl+V. This replaces the previous chunk.
   3. Press Shift+Enter. Expected: `Saved code-01.` and the status table with the count going up.
3. Each file is about 490 KB, so the paste can take a few seconds.
4. If you see `Chunk ... did not arrive intact. Nothing saved.`, the copy was cut short. Copy the same file again and re-run. Every chunk carries its own checksum, so a damaged paste can never be saved.
5. Stop after file 19 if you do not want the PDF text stores. Files 20 to 46 are optional.
6. If the notebook detaches or restarts, re-run Cell 1. Saved chunks are kept, and the status shows the next one you need.

## Step 5: Cell 3 (build and verify)
1. Add Cell 3. Paste `03_CELL3_BUILD.py` into it and run it. It takes about 7 minutes with the PDF stores, less without.
2. Expected output:
   ```
   [1/7] 552 code files written to ... (30 had names rewritten)
   [2/7] skills installed in /Workspace/Users/<you>/.assistant/skills
   [3/7] schema <catalog>.<schema> and 4 volumes ready; 77 data files staged
   [4/7] 77 tables, 18 CHECK constraints
   [5/7] 77 tables loaded, 2,005,448 rows
   [6/7] 36/36 views created
   [7/7] 8/8 functions created
   ==== VERIFY ====
     PASS aircarrier_src_2116_contract_transactions: 948 rows, 4519300323.83 ...
     PASS aircarrier_src_2114_contract_transactions: 927 rows, 4578603345.77 ...
     PASS row counts match source
     PASS CHECK constraints 18/18
     PASS all views created
     PASS all functions created
   RESULT: ALL CHECKS PASSED
   ```
   Without the PDF payload you get 74 tables loaded and a note listing the 3 skipped PDF tables. That is expected.
3. Cell 3 is safe to re-run. Tables that already have the right row count are skipped.

## Step 6: Confirm independently in the SQL editor
Run this yourself. `federal_action_obligation` is a STRING column, so the CAST is required; a plain SUM returns NULL.
```sql
SELECT COUNT(*), SUM(CAST(federal_action_obligation AS DECIMAL(20,2)))
FROM <catalog>.<schema>.aircarrier_src_2116_contract_transactions;   -- 948 | 4519300323.83
```

## Step 7: Start Genie Code in Advana
Open Genie Code and send:
> The Air Carrier tables are in `<catalog>.<schema>`. Read `<CODE_DIR>/01_HANDOFF_BUILD_REFERENCE.md` and `<CODE_DIR>/03_BUILD_FROM_SCRATCH.md`. Path C is done; the data, views and functions are built. Use the aircarrier skills.

The three skills (`aircarrier-investigate`, `aircarrier-verify-figure`, `aircarrier-collection-request`) are already installed.

## Step 8: Clean up (optional, after ALL CHECKS PASSED)
Delete the staging copies, about 23 MB:
* the folder `<CODE_DIR>_pastekit_stage`
* `/Volumes/<catalog>/<schema>/aircarrier_artifacts/_pastekit_data`

## Troubleshooting
* Browser struggles with a 490 KB paste: ask for a smaller-chunk kit (about 250 KB per chunk, roughly 90 pastes).
* `PERMISSION_DENIED` on CREATE SCHEMA, TABLE, VOLUME or FUNCTION: ask the Advana admin for those rights on the catalog, or point `SCHEMA` at a schema you own.
* `Permission denied` writing under `/Workspace`: use serverless or DBR 13.3 or later. Or set `CODE_DIR` to a `/Volumes/...` path you can write to.
* A view or function is listed under FAIL: the message names the missing object. Fix it, then re-run Cell 3.
* Different row counts: the kit is a fixed 2026-11-12 snapshot, so counts only change if a paste was wrong, and the checksums prevent that. Re-run Cell 3 and read the FAIL line.
