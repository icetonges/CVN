# AIR CARRIER PASTE KIT - CELL 1 (SETUP)
# Edit the three CHANGE_ME values, then run this cell. Re-run it after any cluster restart.
CATALOG  = "CHANGE_ME"   # Advana catalog where you can create schemas/tables
SCHEMA   = "CHANGE_ME"   # schema to build into (created if missing)
CODE_DIR = "/Workspace/Users/CHANGE_ME/aircarrier"   # source code is written here
NAME_PREFIX = ""         # leave empty

import os, re, json, hashlib
assert "CHANGE_ME" not in CATALOG + SCHEMA + CODE_DIR, "Edit CATALOG, SCHEMA and CODE_DIR first."
STAGE_DIR = CODE_DIR.rstrip("/") + "_pastekit_stage"
os.makedirs(STAGE_DIR, exist_ok=True)
KIT = {"code": {"sha256": "013b400ecc738fb541f918e7adf95526845e1fff2dbe513e5aac5a8fc50d02d4", "bytes": 3657020, "chunks": ["code-01", "code-02", "code-03", "code-04", "code-05", "code-06", "code-07", "code-08", "code-09", "code-10"]}, "core": {"sha256": "bbd4c3a201def8b781cb56542a5dec9f79eb197ee6ee590c3e535514e7c95b28", "bytes": 3064022, "chunks": ["core-01", "core-02", "core-03", "core-04", "core-05", "core-06", "core-07", "core-08", "core-09"]}, "pdf": {"sha256": "db7e202601cf522f038b97e606d0d26133e4e3016773d275345c013680b4c734", "bytes": 9812064, "chunks": ["pdf-01", "pdf-02", "pdf-03", "pdf-04", "pdf-05", "pdf-06", "pdf-07", "pdf-08", "pdf-09", "pdf-10", "pdf-11", "pdf-12", "pdf-13", "pdf-14", "pdf-15", "pdf-16", "pdf-17", "pdf-18", "pdf-19", "pdf-20", "pdf-21", "pdf-22", "pdf-23", "pdf-24", "pdf-25", "pdf-26", "pdf-27"]}}
CHUNK_SHA = {"code-01": "2a5b1ddbdfb8776cf6a5b25b9f123d9865df9e8b81b4129062618610f3f3036c", "code-02": "462f21cca8001b05cf8f126c93f7c33d294b413f68f2238f72c742fbc313e0aa", "code-03": "3acf0c2adcb60bf8aad6d045ec30a55989cde3d64419566536ac6f452e19368b", "code-04": "76daae2ebe5458183572562c4a5062c79fa21b5fc1682bd174bd1a5f677c92f7", "code-05": "c860defb1a3b05b677617b24a61b8c7ef5f8661336a9c41858184f7230bfb7c2", "code-06": "b81fb6a6e4679a563ec96b2d5812d38c09864b09bc1b3138951d005c972ec93d", "code-07": "ce8b7a1ed149ef8fd4c53c2dd3d2c04f75b73dda10c0fc3c86e836e5422687b2", "code-08": "5abe4b8aeeeb4a655d11fed302eb07bda0bd26ee80ccfb306c5cba5f4ec2fbf2", "code-09": "432baf784b0abcad6602cafddbec30f2c49f71964dd18ecea5af49eb90ea00db", "code-10": "1b95481b34d691c00d9ef8a336b207534d0590402054df6adbf98639ac3b57ef", "core-01": "90581a724024d34bd6daac4abb82b5bf25a274160f55679bc839eb273fef7c2a", "core-02": "ed18a96c9832cc8c4ebb71eca4d8c1f7ab817dfa1e7cd32d55736b58471f662a", "core-03": "8de551bffc50c1dec2e4266e5a8b35bbef5838faf7e3874580831f8961ba56d7", "core-04": "b2cdcec61024749baf2b8d9935696bbc01b7ddafbb242bbdd2dc9dcb0640e99f", "core-05": "68ab349dc4c3a4e074c30b5a4c244f22ee5f7ac70794150d9a9375e592bf6aa5", "core-06": "7588449f5d487c1e7b93c0102ee16d434124fd14deadd5d65e998a50e274c895", "core-07": "466e0102e653189932defc5e7ff2c93d075e85a24643f4404c6fbc8f999e900d", "core-08": "802a569536d133ab00ee99a9cc44c50accaea23a2535c2afaccdd0ff024fcca7", "core-09": "22f8ef5a94e470bcc0407298af60e77dda7e1daf87aa221834c4addcc818f221", "pdf-01": "360b1cdc0d437621e3a24608caaa34ab972b8c84384401720164675b06c4a190", "pdf-02": "ede35e94c880c79ab3a6949da909e8129f9e1416478387b622e930be1486f7e2", "pdf-03": "d28605a8d59ff1ceffd08322748130727f1a40ce1b059a721748ebd953f89ae1", "pdf-04": "7a87e8eeaa04bf88e5b388dde8435eec2352e579594859ecfb739772e0dc2f85", "pdf-05": "4053adb28b1893389ff99a155a6c667270e01cada6b13fce9033c09aa11a284d", "pdf-06": "cbe8b8a208eb9eedb3b5dcff9aea5ca81ee69007914c45c7040557876e7e2d08", "pdf-07": "6034e4690a97a42249a4ba89fcdcece0893a5c5e2441152821adf99b51146d3a", "pdf-08": "be0f1a00cc6f2da14f14385a742186d4bc12866134fa7e5466925550f0fc2f78", "pdf-09": "8f9d7b20beee01f3cc174dc6e6bf0586b5bd6af89896cf706613449468981fa5", "pdf-10": "277d36ea6c00267162b8a7956d2365e9ace211407c24991ca4592a0eea98e3b4", "pdf-11": "003d7d052a3a81eecd0ad96cf065e1556b4ab0838da9a8fa83b7d321fec09b18", "pdf-12": "6ebd65016dcd4bf4bd6989849eaa50054efe0409652f7d72a0044a7b79b76b65", "pdf-13": "96d362f62515ccbea385f662f60d5ca5f97844991dbb81c6050590afc2d611cb", "pdf-14": "89edfbf5f0e8192401c167c8573370e29e1cf149a537e29ce5f4a596379f5c12", "pdf-15": "bba25d11bf4b309a63f116f2c4cd55b612a25eec70ca3646384b888cbc43bf59", "pdf-16": "13ae83e7c63200521f374049c6581f33554719d48d55033d07c439327cd8adc3", "pdf-17": "051aaf51817de5ae1a555ed526d13cc62ff5f804ce2281d0943e7c1b3dffaed0", "pdf-18": "3b5bee1944fc112cfb994e4423479f16e3d294cb58c49f8e16630486cc21e3fe", "pdf-19": "f523a0a4c491e9e76672f1a90246fef3c51e64fcdd9ca4c9d66af3f5702fb712", "pdf-20": "e45308b318696c15242d9f1f6767542a7bbca7e2bb1fbe5940afa24e7c76b900", "pdf-21": "efc59d42211345eaaf990d25b2a29f36a57bc9193c2129151458c15c48fe36ac", "pdf-22": "26bd67759b8d843a8f5425e23844d5b31300556cf859b3da5c7e1b890ae8b4f3", "pdf-23": "e08938e1dcf41dbb3c914a728c22786dcfa258acaa159138f7623fc11deb32c7", "pdf-24": "9e3f80fa822a7d7f40781b35d058fc3ff997682d6932ef7265ecf74dd8ec5790", "pdf-25": "8056542192b5006fa4413befaabfb5cf3e12229c6711931b7458d10d82243341", "pdf-26": "20e6588fd5681dd9a7fbf4ab5431b5a530c57db7644a58394392123a7d208c06", "pdf-27": "6d9475335c3d270405a4681b30ff161d22ffcdc999b9196eab49d7a64e76af16"}

def kit_status():
    have = {f[:-4] for f in os.listdir(STAGE_DIR) if f.endswith(".b64")}
    for p, meta in KIT.items():
        miss = [c for c in meta["chunks"] if c not in have]
        print(f"  {p:5s} {len(meta['chunks'])-len(miss):2d}/{len(meta['chunks'])}  " + ("COMPLETE" if not miss else f"next: {miss[0]}"))

def _put(cid, sha, text):
    b = re.sub(r"\s+", "", text)
    if CHUNK_SHA.get(cid) != sha or hashlib.sha256(b.encode()).hexdigest() != sha:
        raise ValueError(f"Chunk {cid} did not arrive intact. Nothing saved. Copy the whole chunk file again and re-run.")
    with open(f"{STAGE_DIR}/{cid}.b64", "w") as f:
        f.write(b)
    print(f"Saved {cid}.")
    kit_status()

print(f"Setup OK. Pasted chunks are saved in {STAGE_DIR}")
kit_status()
