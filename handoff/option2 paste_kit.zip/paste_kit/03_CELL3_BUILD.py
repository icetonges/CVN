# AIR CARRIER PASTE KIT - CELL 3 (BUILD + VERIFY)
# Run after kit_status() shows code and core COMPLETE. pdf is optional (adds pdf_pages/pdf_tables/pdf_cells).
# Safe to re-run: tables already holding the right row count are skipped.
import base64, io, zipfile, json, hashlib, os, re, shutil
from pyspark.sql import functions as F

T = f"{CATALOG}.{SCHEMA}"
VOLROOT = f"/Volumes/{CATALOG}/{SCHEMA}"
ME = spark.sql("SELECT current_user()").first()[0]
SKILLS_DIR = globals().get("SKILLS_DIR", f"/Workspace/Users/{ME}/.assistant/skills")
def q(n): return f"{T}.{NAME_PREFIX}{n}"
def sub_s(sql): return re.sub(r"\{S\}\.(\w+)", lambda m: q(m.group(1)), sql)

def payload(p):
    meta = KIT[p]; have = set(os.listdir(STAGE_DIR))
    if any(f"{c}.b64" not in have for c in meta["chunks"]): return None
    data = base64.b64decode("".join(open(f"{STAGE_DIR}/{c}.b64").read() for c in meta["chunks"]))
    if hashlib.sha256(data).hexdigest() != meta["sha256"]: raise ValueError(f"payload {p}: checksum failed")
    return zipfile.ZipFile(io.BytesIO(data))
code, core, pdf = payload("code"), payload("core"), payload("pdf")
assert code and core, "code and core must be COMPLETE. Run kit_status()."

# 1. code files, with the old workspace's names rewritten to yours
REWRITE = [
    ("/Volumes/users/xiaobing_shang1_civ/", f"{VOLROOT}/"),
    ("`users`.`xiaobing_shang1_civ`", f"`{CATALOG}`.`{SCHEMA}`"),
    ("users.xiaobing_shang1_civ", T),
    ("/Workspace/Users/xiaobing.shang1.civ@mail.mil/the-one-hub/the-ops-center/.bundle/aircarrier/dev/files", f"{CODE_DIR}/aircarrier_bundle"),
    ("/Workspace/Users/xiaobing.shang1.civ@mail.mil/mcp-servers", f"{CODE_DIR}/mcp-servers"),
]
TEXT = (".py", ".sql", ".yml", ".yaml", ".md", ".toml", ".json", ".txt", ".html", ".csv", ".example", ".cfg", ".ini")
nfiles = nrew = 0
for i in code.infolist():
    if i.is_dir(): continue
    data = code.read(i.filename)
    if i.filename.lower().endswith(TEXT):
        s = data.decode("utf-8", "surrogateescape"); s0 = s
        for a, b in REWRITE: s = s.replace(a, b)
        s = re.sub(r"(?<![\w.`])xiaobing_shang1_civ(?![\w])", SCHEMA, s)
        if s != s0: nrew += 1
        data = s.encode("utf-8", "surrogateescape")
    out = os.path.join(CODE_DIR, i.filename)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "wb") as f: f.write(data)
    nfiles += 1
print(f"[1/7] {nfiles} code files written to {CODE_DIR} ({nrew} had names rewritten)")

# 2. Genie Code skills
for name in sorted({p.split("/")[1] for p in code.namelist() if p.startswith("skills/") and p.endswith("SKILL.md")}):
    os.makedirs(f"{SKILLS_DIR}/{name}", exist_ok=True)
    shutil.copyfile(f"{CODE_DIR}/skills/{name}/SKILL.md", f"{SKILLS_DIR}/{name}/SKILL.md")
print(f"[2/7] skills installed in {SKILLS_DIR}")

# 3. schema, volumes, staged data
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {T}")
for v in ["aircarrier_artifacts", "aircarrier_extracted", "aircarrier_captures", "aircarrier_mcp_probe_runs"]:
    spark.sql(f"CREATE VOLUME IF NOT EXISTS {q(v)}")
DATA = f"{VOLROOT}/{NAME_PREFIX}aircarrier_artifacts/_pastekit_data"
os.makedirs(DATA, exist_ok=True)
for z in [core] + ([pdf] if pdf else []):
    for i in z.infolist():
        if i.filename.endswith(".parquet"):
            with open(f"{DATA}/{i.filename}", "wb") as f: f.write(z.read(i.filename))
spec = json.loads(core.read("spec.json"))
print(f"[3/7] schema {T} and 4 volumes ready; {len(os.listdir(DATA))} data files staged")

# 4. tables + CHECK constraints
def lit(s): return "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'"
ncons = 0
for t in spec["tables"]:
    cols = ",\n  ".join(f"`{c['name']}` {c['type']}" + ("" if c["nullable"] else " NOT NULL")
                        + (f" COMMENT {lit(c['comment'])}" if c.get("comment") else "") for c in t["columns"])
    spark.sql(f"CREATE TABLE IF NOT EXISTS {q(t['name'])} (\n  {cols})" + (f" COMMENT {lit(t['comment'])}" if t.get("comment") else ""))
    have = {r.key for r in spark.sql(f"SHOW TBLPROPERTIES {q(t['name'])}").collect()}
    for cn, expr in t["constraints"].items():
        if f"delta.constraints.{cn}" not in have:
            spark.sql(f"ALTER TABLE {q(t['name'])} ADD CONSTRAINT {cn} CHECK ({expr})")
        ncons += 1
print(f"[4/7] {len(spec['tables'])} tables, {ncons} CHECK constraints")

# 5. load data
loaded, skipped = {}, []
for t in spec["tables"]:
    f = f"{DATA}/{t['name']}.parquet"
    if not os.path.exists(f): skipped.append(t["name"]); continue
    fq = q(t["name"]); cur = spark.table(fq).count()
    if cur != t["rows"]:
        if cur: spark.sql(f"TRUNCATE TABLE {fq}")
        tgt = spark.table(fq).schema
        spark.read.parquet(f).select([F.col(c.name).cast(c.dataType) for c in tgt.fields]).write.insertInto(fq)
    loaded[t["name"]] = spark.table(fq).count()
print(f"[5/7] {len(loaded)} tables loaded, {sum(loaded.values()):,} rows" + (f"; not loaded (pdf payload absent): {skipped}" if skipped else ""))

# 6. views (several passes, so views that read other views get created in order)
pending, verr = list(spec["views"]), {}
for _ in range(8):
    nxt = []
    for v in pending:
        sql = sub_s(v["sql"])
        try: spark.sql(sql); verr.pop(v["name"], None)
        except Exception:
            try: spark.sql(sql.replace("WITH SCHEMA COMPENSATION", "")); verr.pop(v["name"], None)
            except Exception as e: nxt.append(v); verr[v["name"]] = str(e).strip().splitlines()[0][:220]
    if not nxt or len(nxt) == len(pending): pending = nxt; break
    pending = nxt
print(f"[6/7] {len(spec['views'])-len(pending)}/{len(spec['views'])} views created")

# 7. functions
ferr = {}
for fsql in spec["functions"]:
    name = re.search(r"FUNCTION \{S\}\.(\w+)", fsql).group(1)
    try: spark.sql(sub_s(fsql))
    except Exception as e: ferr[name] = str(e).strip().splitlines()[0][:220]
print(f"[7/7] {len(spec['functions'])-len(ferr)}/{len(spec['functions'])} functions created")

# VERIFY
print("\n==== VERIFY ====")
bad_rows = {n: (loaded[n], t["rows"]) for t in spec["tables"] for n in [t["name"]] if n in loaded and loaded[n] != t["rows"]}
cons_now = sum(1 for t in spec["tables"] for r in spark.sql(f"SHOW TBLPROPERTIES {q(t['name'])}").collect() if r.key.startswith("delta.constraints."))
ok = True
for ka in spec["known_answers"]:
    r = spark.sql(f"SELECT COUNT(*) n, CAST(SUM(CAST(federal_action_obligation AS DECIMAL(20,2))) AS STRING) s FROM {q(ka['table'])}").first()
    good = r.n == ka["rows"] and r.s == ka["sum"]; ok &= good
    print(f"  {'PASS' if good else 'FAIL'} {ka['table']}: {r.n} rows, {r.s} (expected {ka['rows']}, {ka['sum']})")
for label, cond, detail in [("row counts match source", not bad_rows, bad_rows),
                            (f"CHECK constraints {cons_now}/{ncons}", cons_now == ncons, ""),
                            ("all views created", not verr, verr),
                            ("all functions created", not ferr, ferr)]:
    ok &= bool(cond); print(f"  {'PASS' if cond else 'FAIL'} {label}" + (f"  {detail}" if not cond else ""))
print("\nRESULT:", "ALL CHECKS PASSED" if ok else "SOME CHECKS FAILED - see above")
