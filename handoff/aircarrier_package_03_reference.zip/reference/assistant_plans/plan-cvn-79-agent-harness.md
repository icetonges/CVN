# CVN\-79 agent harness: inventory and reconciliation plan

This plan adds the rule register, the exception layer and the seven-agent harness to the existing Air Carrier bundle at `/Workspace/Users/xiaobing.shang1.civ@mail.mil/the-one-hub/the-ops-center/.bundle/aircarrier/dev/files`. Per your earlier decision, that workspace copy is the source of truth. The inventory below comes from read-only research. You asked me not to code until you approve, so every To-do waits on that approval and on the five open questions.

## Inventory

**1. Package and how agents are written.**
* The package is a custom framework. It does not use ChatAgent, ResponsesAgent, LangGraph or a supervisor; LangGraph is not even installed.
* `core/` holds contracts, ports (`llm.complete(role=...)`, embed, vector, blob) and adapters (commercial and il5). `core/policy/` holds `gate.py` and `decisions.py`. `core/ledger.py` is the append-only claim ledger.
* `ops/agents/` holds investigator, reader (exhibit, prose and transaction handlers), tieout, challenger, attributor and briefer. Attributor and briefer are stubs.
* Each agent has a thin serverless job entrypoint in `ops/entrypoints/`, plus `ops/dispatcher/routing.py` and `run.py`.
* Rule B1 runs agents as job tasks, not served agents. The package rule is that agents never call each other: each handoff is a state change on a work-register row.
* Models are bound by role in `seed/models.yaml`. Prompts are inline strings.
* There are two other places agents live:
  * The `/ask` agent in `app/api/agent.py`, which has a generic `run_sql` tool.
  * Three deployed MCP apps: mcp-aircarrier-ops, -analyst and -docs.

**2. Platform capabilities.**

| Capability | State |
| --- | --- |
| MLflow / Agent Framework | mlflow 3.12.0 and databricks-agents 1.11.0 are on serverless. The bundle uses neither: no tracing and no Agent Evaluation |
| Model Serving | 55 READY endpoints. Tool calling is verified on opus-5 and opus-4-8. gpt-6-sol rejects tools. opus-5-5 and gpt-6-astra return 403 |
| UC functions | None in `users.xiaobing_shang1_civ` |
| Vector Search | 2 endpoints, both unrelated. Not needed here |
| Genie | 1 unrelated test space. B6 keeps Genie out of the ops path |
| Lakeflow / SDP | No pipelines. Serverless jobs are the pattern |
| Bundles | The bundle exists with targets `dev` and `il5` only. The assistant cannot deploy; you deploy from the Web Terminal |
| ai_query / ai_parse_document | Unused. Extraction goes through pdfplumber/PyMuPDF in docs_core |

**3. Unity Catalog.**
* Catalogs: workspace, models, users, samples and system. The `aircarrier` catalog does not exist, and you have no CREATE CATALOG or CREATE SCHEMA.
* Everything lives in your personal schema `users.xiaobing_shang1_civ` with the `aircarrier_` prefix (49 objects).
* Treated as sources: `aircarrier_src_*`, which are USAspending/FPDS, File C, subawards and funding history copied from public files.
* App-derived: `jb_*`, `pdf_*`, `kg_*`, claim/challenge/gate, work/gaps/variances and the analyst tables.
* None of this data is IPMDAR, CCDR, EVM, CDRL, GL, CIP, DD 250, voucher, GFE/GFM transfer or management reserve data.

**4. Auth.**
* aircarrier-front-center-dev runs as SP `7e1ec6c0`, which has SELECT only. It has no user API scopes.
* User authorization is enabled in this workspace: mcp-a-creator uses the `sql` scope.
* Your only groups are `account users` and `users`. No role groups exist.

## Conflicts with the spec

* **C1, serving vs. jobs.** The spec deploys agents to Model Serving; the package runs them as jobs (B1). I propose keeping jobs: `POST /runs` starts a job run. A ResponsesAgent wrapper can be added later.
* **C2, write tools.** UC functions cannot write. `stage_proposal` and `run_cost_model_scenario` become orchestrator-side Python tools in a hash-pinned allowlist. The seven read tools are UC SQL functions.
* **C3, generic SQL.** The `/ask` agent's `run_sql` breaks the no-generic-SQL invariant. It stays out of the new harness, and you decide whether to remove it.
* **C4, schemas.** The spec wants separate application and source-view schemas, which needs an admin. The fallback is `aircarrier_app_*` and `aircarrier_srcv_*` objects inside one schema with per-object grants. That is weaker isolation.
* **C5, missing source data.** Of the 25 seed rules, only CC-02, CM-01, CM-02 and CM-03 can be written now. CAP-01 and CAP-02 can also be written once CAP-05 is set. The other 19 are seeded with status `blocked_no_source` and name the missing feed; I will not approximate them. The closest approximation, CC-04 via File C TAS expiry, measures obligations rather than charged cost, so it is also flagged.
* **C6, roles.** Role groups and row filters need account-admin group creation.
* **C7, bundle targets.** The bundle has `dev` and `il5`; the spec wants `dev`, `staging` and `prod`. I propose adding `staging` and keeping `il5` as prod.
* **C8, constants in code.** The existing claim gate hard-codes 13,409.970 and the 1% floor. That is outside the new system's scope, but I flag it.
* **C9, atomic apply.** A single-transaction apply needs Delta multi-statement transactions on the warehouse. I will verify this first; with no transactions there, invariant 9 cannot be met.
* **C10, search scope.** `regexAssetSearch` does not index the bundle files: it returned 0 hits for a known `run_sql`. Acceptance test 9 therefore runs as a grep plus SHOW GRANTS job in CI.
* **C11, where the API lives.** Proposal: a FastAPI router under `app/api/v1/` in the existing front-center app.

## Unresolved decisions (the question card was skipped)

None of the five questions were answered, and I have chosen no defaults for them:
* CAP-05 baseline and recognized adjustments.
* The AV-06 placed-in-service event.
* The CC-01 WBS level.
* OBO availability. The evidence suggests yes, but it is unconfirmed.
* The checker endpoint. My proposal is a different model family, after a tool-calling probe; this is my suggestion, not your choice.

The rule seed, the apply path and the checker To-dos are provisional until these are answered, and this plan is not ready to execute. You also need to approve or amend C1–C11.

## Reconciliation

* **Adopt as written:** the Delta tables (prefixed), rules as data, the insert-only audit, citations, the checker verdict schema, kept failures, and the API contract.
* **Adapt:** orchestrator = dispatcher; agents follow the package pattern, plus prompt files; tools follow C2; the rule engine is a job plus a synchronous warehouse call from `POST /rules`; deployment follows C1 and C7.
* **Replace:** none of the existing agents. The new specialists are additive under `ops/agents/harness/`.

## To-dos
- **Get approval of C1-C11 and answers to the five open questions**: Blocking. Re-ask CAP-05 figure and adjustments, AV-06 event, WBS level, OBO, checker endpoint; record answers verbatim in docs/DECISIONS.md before any code.
- **Probe platform prerequisites read-only**: Verify multi-statement Delta transactions on the warehouse, tool-calling on the chosen checker endpoint, and that the admin can create two schemas and the role groups; stop if transactions are unavailable.
- **Create application tables and current\_rules view**: rule\_register, rule\_register\_audit, exceptions, agent\_runs, agent\_steps, checker\_verdicts, proposals, decisions, documents, model\_runs with the spec columns; verify DESCRIBE matches spec column list exactly.
- **Create read-only source views and SELECT-only grants**: Views over aircarrier\_src\_\* and jb\_\* in the source-view schema or prefix; grant agent SP SELECT on views only; verify with SHOW GRANTS that no MODIFY exists on any source object.
- **Register the seven read tools as UC SQL functions**: get\_exception, get\_rule, get\_cost\_capture, get\_evm\_control\_account, get\_cap\_ledger, get\_cip\_transactions, get\_document\_text; functions over missing feeds return an explicit no\_source row; test each with a known record.
- **Implement stage\_proposal and run\_cost\_model\_scenario as orchestrator-side tools**: stage\_proposal inserts only into proposals with status pending; cost model writes model\_runs; verify no other table is writable by the agent SP.
- **Seed rule\_register with versioned rows (provisional)**: Write expression\_sql for CC-02, CM-01..03, CAP-01..02; mark the 19 no-source rules blocked\_no\_source naming the missing feed; CAP-05/AV-06/CC-01 params only from user answers.
- **Build the rule evaluation job and synchronous trigger**: Serverless job plus warehouse call from POST /rules; stamps rule\_version at detection; drops rows lacking owner\_office or required\_action; test that a param edit changes the population.
- **Implement orchestrator, checker gate and five specialists plus intake**: ops/agents/harness/ modules, prompts/ files, per-agent tool allowlists, MLflow tracing with trace id into agent\_runs; fail verdict stops the run and is kept.
- **Implement document intake path**: Volume landing with sha256 row, docs\_core extraction with page and text span per field, SQL value-list validation, outcomes ready/duplicate/blocked with reason.
- **Implement server-side apply/reject and role resolution (provisional on OBO)**: UC group to role mapping, row filters on component tables, decision row with authority\_check\_result, apply plus KSD/metric recompute in one transaction; refusals written.
- **Add API v1 router to the front-center backend**: All 13 endpoints in the contract; every figure carries record ids; no UI code.
- **Add bundle staging target, harness job, experiment and eval suite**: Agent Evaluation with the 10 acceptance tests and a citation-completeness scorer, runnable in CI; no-source-write grep plus SHOW GRANTS job.
- **Verify all ten acceptance tests and report**: Run the eval suite and grep/grants job, confirm each test passes with evidence, and report the exact command and path where the no-write search runs.