# Air Carrier work queue: offline demo package

Temporary workaround for Advana FM until Unity Catalog access is granted. Snapshot of
aircarrier-front-center-dev /work taken 2026-11-13T21:48:10Z.

## Files

| File | What it is | Use |
|---|---|---|
| AirCarrier_WorkQueue_Offline_Demo (notebook) | One self-contained notebook: the data (sha256-checked), the page code, the templates | Export it (File > Export > Source file or IPython Notebook), then in Advana FM: Workspace > Import. Run all. |
| work_queue.html | The page, already rendered, CSS inline | Open in any browser. No Databricks needed. |
| workqueue_data.json | The same data as plain JSON: meta, the 6 page queries, 9 source tables | Reference copy; the notebook does not need it. |

## In Advana FM

1. Import the notebook into your home folder.
2. Attach any Python compute (serverless or cluster) and Run all.
3. It writes aircarrier_workqueue_data/ next to the notebook (queries/, tables/, engine/, manifest.json, work_queue.html), renders the page, and checks 14 Decide / 16 Unblock (17 rules held) / 45 System.
4. Nothing reads or writes Unity Catalog. Cell 7 makes session-only Spark temp views (wq_*), which need no catalog.

## Limits

* Frozen snapshot: decisions made later do not show. Re-export from the dev workspace to refresh.
* Read only: run pages, rule pages and Apply / Reject are not included; links are disabled.
* The lane logic is lanes() from app/api/harness.py (deployment 01f1deb063ca16d7ad79d460eaeedf22), copied verbatim; only the SQL reads are replaced by the JSON files.
* Contains role_map (1 row: your email as PMS379 holder) and full proposal payloads. Treat it like the source tables.

Payload sha256: be9471471a15e3bb3b73277b90ef6e5187a6b4d66f0b825aeab809edf26004fc
