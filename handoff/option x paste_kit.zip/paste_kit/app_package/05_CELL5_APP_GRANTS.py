# AIR CARRIER PASTE KIT - CELL 5 (APP GRANTS)
# Run AFTER Cell 4 deploys the app.
# Gives the app's service principal SELECT on the 23 v_doc_* views
# and READ/WRITE on the captures volume.

from databricks.sdk import WorkspaceClient

w = WorkspaceClient()
app = w.apps.get(APP_NAME)
sp_name = app.service_principal_name
T = f"{CATALOG}.{SCHEMA}"

# The 23 v_doc_* views the app reads
V_DOC_VIEWS = [
    "v_doc_anchor_chain", "v_doc_asset", "v_doc_attribution", "v_doc_cap_history",
    "v_doc_clue_map", "v_doc_contracts", "v_doc_corpus", "v_doc_cost_categories",
    "v_doc_delivery", "v_doc_equipment", "v_doc_estimate_history", "v_doc_federal_accounts",
    "v_doc_funding_streams", "v_doc_gaps", "v_doc_industrial", "v_doc_layers",
    "v_doc_obligations", "v_doc_program", "v_doc_rules", "v_doc_sources",
    "v_doc_subawards", "v_doc_timeline", "v_doc_variances",
]

# Also grant on the operational tables the app writes to
WRITE_TABLES = [
    "aircarrier_app_agent_runs", "aircarrier_app_agent_steps",
    "aircarrier_app_checker_verdicts", "aircarrier_app_model_runs",
    "aircarrier_app_proposals", "aircarrier_app_decisions",
    "aircarrier_app_decision_attempts", "aircarrier_app_determinations",
    "aircarrier_app_documents", "aircarrier_app_exceptions",
    "aircarrier_app_metrics",
]

prefix = NAME_PREFIX or ""
grants = []
# USE CATALOG and USE SCHEMA
grants.append(f"GRANT USE CATALOG ON CATALOG {CATALOG} TO `{sp_name}`")
grants.append(f"GRANT USE SCHEMA ON SCHEMA {T} TO `{sp_name}`")

# SELECT on views
for v in V_DOC_VIEWS:
    grants.append(f"GRANT SELECT ON TABLE {T}.{prefix}{v} TO `{sp_name}`")

# SELECT + MODIFY on operational tables
for t in WRITE_TABLES:
    grants.append(f"GRANT SELECT, MODIFY ON TABLE {T}.{prefix}{t} TO `{sp_name}`")

# READ/WRITE on captures volume
grants.append(f"GRANT READ VOLUME, WRITE VOLUME ON VOLUME {T}.{prefix}aircarrier_captures TO `{sp_name}`")

ok = err = 0
for g in grants:
    try:
        spark.sql(g)
        ok += 1
    except Exception as e:
        err += 1
        print(f"  WARN: {g[:80]}... -> {str(e).splitlines()[0][:120]}")

print(f"Grants: {ok} applied, {err} failed")
print(f"SP '{sp_name}' can now read the 23 v_doc_* views and write to operational tables.")
print(f"\nVisit {w.apps.get(APP_NAME).url} to verify the app loads.")
