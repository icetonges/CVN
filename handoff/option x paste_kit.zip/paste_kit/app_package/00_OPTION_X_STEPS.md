# Air Carrier Option X: paste kit + uploadable app package

Combines two transfer methods:
* **Paste kit** (from `paste_kit/`): tables, views, functions, skills, source code — moved by copy-and-paste into one Advana notebook (tested 2026-11-12, ALL CHECKS PASSED)
* **App upload** (from `paste_kit/app_package/`): the Dragon front-end web app — moved as a single 6.4 MB zip uploaded through Advana's file import

## What you end up with (beyond Path C)

Everything Path C delivers, PLUS:
* The Dragon web app running as a Databricks App at its own URL
* 29 HTML pages (dashboard, gaps, variances, cost, ask, knowledge, work, etc.)
* The SI agent team (specialist investigation with proposals and verdicts)
* Live UC backend reading the 23 v_doc_* views
* The knowledge base (shipped inside the app as app/data/kb/)

## Prerequisites

* Advana FM workspace where you can:
  - Create notebooks and run Python on serverless or DBR >= 13.3
  - Upload/import files (you confirmed HTML works; the zip also contains .py, .json, .jpg, .css, .js)
  - CREATE SCHEMA, CREATE TABLE, CREATE VOLUME, CREATE FUNCTION in a catalog
  - Create a Databricks App (`databricks apps create` permission)
  - Access a SQL warehouse (for the live data backend)
  - Access model serving endpoints (for the agent, reasoning, checker chains)

---

## Downloads: 2 things from 2 folders

### Download 1: the paste kit folder
**Location**: `package/paste_kit/` (EXCLUDING the `app_package/` subfolder)
**How**: Right-click `paste_kit` → Export → Source file → unzip on your computer
**Contains**:
```
paste_kit/
  00_STEPS.md                    ← Path C instructions (still valid for steps 1-5)
  01_CELL1_SETUP.py              ← Cell 1: config (edit 3 values)
  02_CELL2_PASTE_HERE.txt        ← reminder
  03_CELL3_BUILD.py              ← Cell 3: build tables/views/functions
  chunks/
    01_code-01.py ... 46_pdf-27.py   ← 46 paste chunks (~490 KB each)
  app_package/
    aircarrier_app.zip           ← Download 2 (see below)
    04_CELL4_APP_DEPLOY.py       ← Cell 4: deploy the app
    05_CELL5_APP_GRANTS.py       ← Cell 5: grant SP permissions
    06_CELL6_APP_TEST.py         ← Cell 6: smoke test
```

### Download 2: the app zip
**Location**: `package/paste_kit/app_package/aircarrier_app.zip`
**Size**: 6.37 MB, 125 files
**How**: Click the file → download button (↓)
**Contains**: The complete Dragon app (Python, 29 HTML templates, CSS, JS, images, JSON data, knowledge base index, vendored search module). Two JSON metadata files have `${CATALOG}.${SCHEMA}` placeholders that Cell 4 fills in at deploy time.

---

## Step-by-step

### Phase 1: Build the data layer (paste kit, ~30 min paste + 7 min build)

Follow `00_STEPS.md` steps 0 through 5 exactly:

1. **Step 0**: Verify paste works between browsers
2. **Step 1**: Download the paste kit, unzip locally
3. **Step 2**: Create notebook `Air Carrier Paste Kit` in Advana, attach serverless
4. **Step 3**: Paste `01_CELL1_SETUP.py` into Cell 1, edit:
   - `CATALOG = "your_catalog"`
   - `SCHEMA = "your_schema"`
   - `CODE_DIR = "/Workspace/Users/your@email/aircarrier"`
5. **Step 4**: Paste chunks 01 through 19 (required) into Cell 2, one at a time
   - Optional: chunks 20-46 for PDF text stores
6. **Step 5**: Paste `03_CELL3_BUILD.py` into Cell 3, run it
   - Wait for `RESULT: ALL CHECKS PASSED`

### Phase 2: Upload the app zip (~2 min)

1. In Advana, navigate to your workspace folder (e.g. `/Workspace/Users/your@email/`)
2. Click **Import** or drag-drop `aircarrier_app.zip` into the folder
3. Note the full path where it landed (e.g. `/Workspace/Users/your@email/aircarrier_app.zip`)

### Phase 3: Deploy the app (~5 min)

1. Back in your paste kit notebook, add **Cell 4**
2. Paste `04_CELL4_APP_DEPLOY.py` and edit:
   - `APP_ZIP_PATH = "/Workspace/Users/your@email/aircarrier_app.zip"` (where you uploaded it)
   - `WAREHOUSE_ID = "..."` (from the SQL Warehouses page in Advana)
   - Model endpoint names (change only if Advana has different names than the defaults)
3. Run Cell 4. It:
   - Extracts 125 app files into `CODE_DIR/app/`
   - Replaces the `${CATALOG}.${SCHEMA}` placeholders with your real values
   - Creates the Databricks App (or reuses it if it exists)
   - Sets all 15 environment variables
   - Deploys and waits for RUNNING
   - Prints the app URL

### Phase 4: Grant permissions (~1 min)

1. Add **Cell 5**, paste `05_CELL5_APP_GRANTS.py`, run it
2. It gives the app's service principal:
   - SELECT on the 23 `v_doc_*` views (the app's data source)
   - SELECT + MODIFY on 11 operational tables (agent runs, proposals, verdicts, etc.)
   - READ + WRITE on the captures volume

### Phase 5: Test (~2 min)

1. Add **Cell 6**, paste `06_CELL6_APP_TEST.py`, run it
2. Expected: all checks PASS
3. Open the printed URL in your browser — you should see the Kennedy page

---

## What each cell does (summary)

| Cell | File | What it does | Time |
|------|------|-------------|------|
| 1 | 01_CELL1_SETUP.py | Config (catalog, schema, code dir) | instant |
| 2 | chunks/*.py (46 files, one at a time) | Paste data + code payload | ~30 min |
| 3 | 03_CELL3_BUILD.py | Tables, views, functions, skills | ~7 min |
| 4 | 04_CELL4_APP_DEPLOY.py | Extract app zip, create + deploy app | ~5 min |
| 5 | 05_CELL5_APP_GRANTS.py | SP grants on views and tables | ~1 min |
| 6 | 06_CELL6_APP_TEST.py | Smoke test (app status, URL, data, grants) | ~1 min |

## Model endpoints

The app needs 4 model serving endpoints. These are the commercial defaults:

| Role | Default endpoint | Requirement |
|------|-----------------|-------------|
| Agent | databricks-gpt-5-5 | Must support function/tool calling |
| Reasoning | databricks-gpt-6-1-sol | Must return structured JSON |
| Checker | databricks-gemini-3-8-flash | Different model family than agent |
| Fallback | databricks-grok-4-7 | Shared fallback for all chains |

If Advana has different endpoint names, change them in Cell 4 before running.

## Troubleshooting

* **"Must specify environment variable source"**: The `DATABRICKS_WAREHOUSE_ID` env var must be set to the actual warehouse ID string, not `value_from`. Cell 4 handles this correctly.
* **App starts but pages show "extracts only"**: The SP doesn't have SELECT on the v_doc views. Re-run Cell 5.
* **App starts but /ask returns errors**: The SP doesn't have CAN_QUERY on the model endpoints. Add the endpoints as app resources via the Apps UI or CLI.
* **"Permission denied" on CREATE APP**: Ask the Advana admin for Apps permissions.
* **Import rejects the .zip**: Try importing the individual files instead. Unzip `aircarrier_app.zip` on your computer, then import the folder structure file by file. Or ask if .py and .json imports are also allowed.
* **Knowledge base shows "no index"**: The KB ships inside the app at `app/data/kb/`. If it's not found, check that the zip extraction wrote `data/kb/chunks.json` and `data/kb/lexical.json` inside `CODE_DIR/app/`.
