# AIR CARRIER PASTE KIT - CELL 6 (APP TEST)
# Run AFTER Cell 4 (DEPLOY) and Cell 5 (GRANTS).
# Verifies the app is reachable, the views are queryable, and the SP has the right grants.

import os, time, json, requests
from databricks.sdk import WorkspaceClient

w = WorkspaceClient()
app = w.apps.get(APP_NAME)
T = f"{CATALOG}.{SCHEMA}"
prefix = NAME_PREFIX or ""

print("==== APP SMOKE TEST ====")
ok = True

# 1. App status
state = app.app_status.state.value if app.app_status else "UNKNOWN"
print(f"  [{'PASS' if state=='RUNNING' else 'FAIL'}] App status: {state}")
ok &= (state == "RUNNING")

# 2. App URL reachable (unauthenticated, expect redirect or 200)
url = app.url
try:
    r = requests.get(url, timeout=15, allow_redirects=False)
    reachable = r.status_code in (200, 302, 303, 307, 401, 403)
    print(f"  [{'PASS' if reachable else 'FAIL'}] URL reachable: {url} (HTTP {r.status_code})")
    ok &= reachable
except Exception as e:
    print(f"  [FAIL] URL unreachable: {e}")
    ok = False

# 3. App files on disk
APP_DIR = os.path.join(CODE_DIR, "app")
file_count = sum(1 for r, _, fs in os.walk(APP_DIR) for _ in fs)
print(f"  [{'PASS' if file_count >= 120 else 'FAIL'}] App files on disk: {file_count} (expect >= 120)")
ok &= (file_count >= 120)

# 4. Key files present
for check in ["main.py", "app.yaml", "requirements.txt", "templates/kennedy.html",
              "api/__init__.py", "api/live.py", "_ops/ops/ingest/search.py",
              "data/kb/chunks.json", "data/rules.json", "static/css/app.css"]:
    exists = os.path.exists(os.path.join(APP_DIR, check))
    if not exists:
        print(f"  [FAIL] Missing: {check}")
        ok = False

# 5. Hardcoded refs check (should be none after rewrite)
import re
stale = []
for root, _, files in os.walk(APP_DIR):
    for f in files:
        if not f.endswith((".py",".html",".yaml",".json",".js",".css",".md")): continue
        content = open(os.path.join(root, f), errors="ignore").read()
        if "xiaobing_shang1_civ" in content or "xiaobing.shang1.civ@mail.mil" in content:
            stale.append(os.path.relpath(os.path.join(root, f), APP_DIR))
print(f"  [{'PASS' if not stale else 'FAIL'}] Stale hardcoded refs: {stale or 'none'}")
ok &= (not stale)

# 6. v_doc views queryable
v_doc_ok = 0
v_doc_err = []
for v in ["v_doc_contracts", "v_doc_gaps", "v_doc_obligations", "v_doc_corpus", "v_doc_sources"]:
    try:
        n = spark.sql(f"SELECT count(*) FROM {T}.{prefix}{v}").first()[0]
        v_doc_ok += 1
    except Exception as e:
        v_doc_err.append(v)
print(f"  [{'PASS' if not v_doc_err else 'FAIL'}] v_doc views sampled: {v_doc_ok}/5 ok" +
      (f", failed: {v_doc_err}" if v_doc_err else ""))
ok &= (not v_doc_err)

# 7. Known answer still passes
r = spark.sql(f"SELECT COUNT(*) n, CAST(SUM(CAST(federal_action_obligation AS DECIMAL(20,2))) AS STRING) s FROM {T}.{prefix}aircarrier_src_2116_contract_transactions").first()
ka_ok = (r.n == 948 and r.s == "4519300323.83")
print(f"  [{'PASS' if ka_ok else 'FAIL'}] Known answer: {r.n} rows, {r.s}")
ok &= ka_ok

# 8. Env vars on the deployment
dep = app.active_deployment
if dep and dep.env_vars:
    env_names = {ev.name for ev in dep.env_vars}
    required = {"AIRCARRIER_CATALOG", "AIRCARRIER_SCHEMA", "AIRCARRIER_DATA_BACKEND",
                "DATABRICKS_WAREHOUSE_ID", "AIRCARRIER_AGENT_MODEL"}
    missing = required - env_names
    print(f"  [{'PASS' if not missing else 'FAIL'}] Env vars: {len(env_names)} set" +
          (f", missing: {missing}" if missing else ""))
    ok &= (not missing)
else:
    print("  [FAIL] No active deployment or env vars")
    ok = False

print(f"\nRESULT: {'ALL CHECKS PASSED' if ok else 'SOME CHECKS FAILED'}")
