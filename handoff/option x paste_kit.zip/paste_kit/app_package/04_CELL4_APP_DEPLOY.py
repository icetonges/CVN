# AIR CARRIER PASTE KIT - CELL 4 (APP DEPLOY)
# Run AFTER Cell 3 (BUILD) passes and AFTER you upload aircarrier_app.zip to your workspace.
#
# This cell:
#   1. Unzips the app into CODE_DIR/app/
#   2. Rewrites the 2 metadata JSON files with your catalog.schema
#   3. Creates the Databricks App (or finds it if it exists)
#   4. Sets the 15 environment variables
#   5. Deploys the app
#   6. Waits for it to start and prints the URL
#
# PREREQUISITES:
#   - Cell 1 (SETUP) has been run (CATALOG, SCHEMA, CODE_DIR are set)
#   - Cell 3 (BUILD) ended with ALL CHECKS PASSED
#   - aircarrier_app.zip is uploaded to your workspace (any path you can read)

# === EDIT THESE ===
APP_ZIP_PATH   = "/Workspace/Users/CHANGE_ME/aircarrier_app.zip"  # where you uploaded the zip
APP_NAME       = "aircarrier-front-center"                        # Databricks App name (no spaces)
WAREHOUSE_ID   = "CHANGE_ME"                                      # SQL warehouse ID (from SQL Warehouses page)

# Model endpoints available in Advana. Change these to match what your workspace has.
AGENT_MODEL           = "databricks-gpt-5-5"
AGENT_FALLBACKS       = "databricks-gemini-3-8-flash,databricks-grok-4-7"
REASONING_MODEL       = "databricks-gpt-6-1-sol"
REASONING_FALLBACKS   = "databricks-grok-4-7,databricks-gemini-3-8-flash"
CHECKER_MODEL         = "databricks-gemini-3-8-flash"
CHECKER_FALLBACKS     = "databricks-grok-4-7"
# =================

import os, re, io, zipfile, json, time
from databricks.sdk import WorkspaceClient

assert "CHANGE_ME" not in APP_ZIP_PATH + WAREHOUSE_ID, "Edit APP_ZIP_PATH and WAREHOUSE_ID first."
T = f"{CATALOG}.{SCHEMA}"
APP_DIR = os.path.join(CODE_DIR, "app")

# 1. Unzip the app
print("[1/6] Extracting app...")
with zipfile.ZipFile(APP_ZIP_PATH) as zf:
    for info in zf.infolist():
        if info.is_dir(): continue
        data = zf.read(info.filename)
        # Rewrite the 2 placeholder refs in JSON metadata
        if info.filename.endswith(".json"):
            s = data.decode("utf-8", "surrogateescape")
            s = s.replace("${CATALOG}.${SCHEMA}", T)
            data = s.encode("utf-8", "surrogateescape")
        out = os.path.join(APP_DIR, info.filename)
        os.makedirs(os.path.dirname(out), exist_ok=True)
        with open(out, "wb") as f:
            f.write(data)
app_files = sum(1 for r, _, fs in os.walk(APP_DIR) for _ in fs)
print(f"  {app_files} files in {APP_DIR}")

# 2. Verify key files exist
for check in ["main.py", "app.yaml", "requirements.txt", "templates/kennedy.html",
              "api/__init__.py", "api/live.py", "_ops/ops/ingest/search.py"]:
    assert os.path.exists(os.path.join(APP_DIR, check)), f"Missing: {check}"
print("[2/6] All key app files verified")

# 3. Create or find the app
w = WorkspaceClient()
try:
    app = w.apps.get(APP_NAME)
    print(f"[3/6] App '{APP_NAME}' already exists (SP: {app.service_principal_name})")
except Exception:
    print(f"[3/6] Creating app '{APP_NAME}'...")
    app = w.apps.create_and_wait(
        name=APP_NAME,
        description="Air Carrier front center. CVN-79 pilot.",
    )
    print(f"  Created. SP: {app.service_principal_name}")

# 4. Build env vars
env_vars = {
    "AIRCARRIER_CATALOG":           CATALOG,
    "AIRCARRIER_SCHEMA":            SCHEMA,
    "AIRCARRIER_STORE_PREFIX":      NAME_PREFIX or "aircarrier_",
    "AIRCARRIER_DATA_BACKEND":      "uc",
    "AIRCARRIER_ADAPTER":           "commercial",
    "AIRCARRIER_KB_DIR":            f"/Volumes/{CATALOG}/{SCHEMA}/{NAME_PREFIX}aircarrier_extracted/kb",
    "DATABRICKS_WAREHOUSE_ID":      WAREHOUSE_ID,
    "AIRCARRIER_SI_PERSIST":        "delta",
    "AIRCARRIER_AGENT_MODEL":       AGENT_MODEL,
    "AIRCARRIER_AGENT_FALLBACKS":   AGENT_FALLBACKS,
    "AIRCARRIER_REASONING_MODEL":   REASONING_MODEL,
    "AIRCARRIER_REASONING_FALLBACKS": REASONING_FALLBACKS,
    "AIRCARRIER_CHECKER_MODEL":     CHECKER_MODEL,
    "AIRCARRIER_CHECKER_FALLBACKS": CHECKER_FALLBACKS,
    "AIRCARRIER_CAPTURE_VOLUME":    f"/Volumes/{CATALOG}/{SCHEMA}/{NAME_PREFIX}aircarrier_captures",
}
print(f"[4/6] {len(env_vars)} env vars configured")

# 5. Deploy
from databricks.sdk.service.apps import AppDeployment, AppDeploymentMode
from databricks.sdk.service.apps import EnvVariable

env_list = [EnvVariable(name=k, value=v) for k, v in env_vars.items()]
print(f"[5/6] Deploying from {APP_DIR}...")
deployment = w.apps.deploy_and_wait(
    app_name=APP_NAME,
    source_code_path=APP_DIR,
    mode=AppDeploymentMode.SNAPSHOT,
    env_vars=env_list,
)
print(f"  Deployment: {deployment.deployment_id}")
print(f"  Status: {deployment.status.state.value} - {deployment.status.message}")

# 6. Wait for running
print("[6/6] Waiting for app to start...")
for _ in range(30):
    app = w.apps.get(APP_NAME)
    if app.app_status and app.app_status.state.value == "RUNNING":
        break
    time.sleep(10)
app = w.apps.get(APP_NAME)
print(f"  App status: {app.app_status.state.value}")
print(f"  URL: {app.url}")

print(f"\n==== APP DEPLOYED ====")
print(f"  Name: {APP_NAME}")
print(f"  URL: {app.url}")
print(f"  Data: {T} (backend=uc, reading v_doc_* views)")
print(f"  Agent: {AGENT_MODEL}")
print(f"  Reasoning: {REASONING_MODEL}")
print(f"  Checker: {CHECKER_MODEL}")
print(f"\nNext: run Cell 5 (GRANTS) to give the app's SP SELECT on the views.")
