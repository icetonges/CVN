# Genie Code setup prompt for Advana FM: Air Carrier (CVN-79) build

How to use: upload this package to Advana FM. Then open Genie Code in the Advana workspace, paste everything between the two lines marked PROMPT START and PROMPT END, and fill in the <angle-bracket> values you already know. Work through it one phase at a time. Genie Code should stop at every CHECKPOINT and wait for your go-ahead.

What is known vs. assumed about Advana FM:
* Known from the build's own docs (docs/DEPLOY.md, "The GitLab Dragon path"): a Databricks App in Advana FM is deployed only through the project's own GitLab repository and the Dragon pipeline, and that pipeline receives `app/` and nothing else. That is why `app/` is self-contained and `core/` is vendored into it by `tools/sync_core_to_app.py`.
* Assumed, to be confirmed in Phase 0: there is no outbound internet and no PyPI at build or run time (wheels must be vendored or come from an internal mirror); catalogs are provisioned by platform admins; model serving endpoint names differ from commercial; the user is not a workspace admin and cannot create service principals or OAuth secrets.

---------------------------------------- PROMPT START ----------------------------------------

You are setting up the "Air Carrier" CVN-79 cost reconciliation build in this Advana FM Databricks workspace. It was built in a commercial Databricks workspace and exported as a package. I uploaded it to: <PACKAGE_PATH, e.g. /Workspace/Users/<me>/aircarrier_package or /Volumes/<cat>/<schema>/<vol>/package>.

Read these first, before anything else:
1. <PACKAGE_PATH>/01_HANDOFF_BUILD_REFERENCE.md (what everything is, the known answers, troubleshooting)
2. <PACKAGE_PATH>/source/aircarrier_bundle/docs/DEPLOY.md and deploy/TRANSFER.md
3. <PACKAGE_PATH>/source/aircarrier_bundle/databricks.yml and resources/*.yml
4. <PACKAGE_PATH>/MANIFEST.json (sha256 of every file)

Ground rules for the whole setup:
* This is a DoD environment. Follow its limits; never try to get around them. If something is blocked (egress, permissions, a disabled feature), stop, tell me exactly what was blocked and which office or role can unblock it, and draft the request. Do not invent workarounds that skip a control.
* Make no outbound internet calls. Don't pip install from PyPI unless Phase 0 proves an approved mirror exists. Use vendored wheels or the internal mirror.
* Ask me before every write, grant, deploy, job creation or app change. Read-only discovery needs no approval.
* Don't invent values (catalog names, endpoint names, role holders, window_days, unit defaults). When a value is unknown, list it as an open question.
* Keep the build's invariants: the claim ledger is append-only; rule_register is INSERT-ONLY (retire with audit events); SQL is composed through app/api/sqlsafe.compose(); the checker model must be a different family from the agent and reasoning models; never sum total_dollars_obligated.
* After each phase, verify the result by a different method than the one that produced it, and report what you checked.
* Keep a running log at <PACKAGE_PATH>/SETUP_LOG.md: each step, the command or action, the result, and the date.

PHASE 0 - Discover the environment (read-only)
Find and report:
 a. Workspace URL, cloud (GovCloud?), Databricks Runtime and serverless availability, SQL warehouses I can use (id, name, type).
 b. Unity Catalog: the catalogs and schemas I can USE and CREATE TABLE/VOLUME in. Recommend one target <CATALOG>.<SCHEMA>. The bundle never creates catalogs or schemas.
 c. Model serving: list the endpoints I can query. For each build role (agent = chat + function tools; reasoning = JSON, no tools; checker = a different family; extraction; embedding), propose an endpoint, and prove it with one tiny test call (tool call for agent, JSON for reasoning).
 d. Databricks Apps: is it enabled? Can I create apps, or only through the Dragon pipeline? Is there a *.databricksapps.mil domain?
 e. Dragon pipeline: find the project's GitLab repo or template. Ask me for its URL if you can't find it. Report the required stages, the hardened base image, how secrets and env vars are injected, and whether it can run `databricks bundle deploy` or only deploys an `app/` folder.
 f. Python packages: run `pip download`/`pip index` against the configured index (no public internet) to see whether an internal mirror serves fastapi, uvicorn, jinja2, pyyaml, databricks-sdk, fastmcp>=2.14,<3, pypdf, pdfplumber, openpyxl, pandas, pyarrow. If not, list exactly which wheels must be vendored.
 g. The Databricks CLI version in the web terminal, and whether bundle commands are allowed.
CHECKPOINT 0: show me a table of findings plus the proposed values for CATALOG, SCHEMA, WAREHOUSE_ID and the 5 model roles. Wait for approval.

PHASE 1 - Verify the package
 a. Recompute sha256 for every file listed in MANIFEST.json and report mismatches or missing files. A missing file is a failed transfer, not a reason to skip.
 b. Confirm the counts: data/tables has 80 .parquet + 2 .jsonl + _row_counts.json (83 files total); data/volumes/aircarrier_artifacts has 200 files; notebooks/ has 6 notebooks at the top level, plus 5 duplicate copies under notebooks/ipynb/; MANIFEST.json lists 1,281 files, about 284.8 MB.
CHECKPOINT 1.

PHASE 2 - Unity Catalog objects (needs approval)
 a. Create the 5 volumes from platform/uc/00_volumes.sql in <CATALOG>.<SCHEMA>.
 b. Copy data/volumes/* into the matching volumes byte for byte, preserving the folder names (the artifact folders are content-addressed). Check sha256 after the copy.
 c. Rewrite platform/uc/01_tables.sql: replace all 84 occurrences of `users`.`xiaobing_shang1_civ` with <CATALOG>.<SCHEMA> (use `sed -i 's/users\.xiaobing_shang1_civ/<CATALOG>.<SCHEMA>/g'` or equivalent). Also check TBLPROPERTIES: remove `delta.feature.variantShredding-preview` and `delta.feature.variantType-preview` if the runtime rejects them (they appear only on the mcp_a_creator_otel_* tables). Keep all `delta.constraints.*` entries — those are CHECK constraints that the app relies on. Show me the diff. Then run it. Ask whether to skip the scratch tables (aircarrier_apptest_*, aircarrier_app_probe_txn*).
 d. Load the data with platform/uc/05_load_tables_from_package.py: set SRC to a volume path (Spark cannot read workspace FUSE paths as data sources), and TARGET to <CATALOG>.<SCHEMA>. The loader uses INSERT INTO (not overwrite) to preserve the CHECK constraints from step c. Run 01_tables.sql FIRST, then the loader. After loading, spot-check that SHOW CREATE TABLE on aircarrier_app_checker_verdicts still shows the `verdict_enum` constraint. Every table's count must equal _row_counts.json source_rows.
 e. Create the views: rewrite platform/uc/02_views.sql (replace all 38 occurrences of `users`.`xiaobing_shang1_civ` with <CATALOG>.<SCHEMA>). No view depends on another view, so ordering doesn't matter, but all must run after the tables exist.
 f. Recreate the 8 functions. 7 are in source/aircarrier_bundle/deploy/harness_tools.sql; the 8th (`aircarrier_app_rule_at`) is in deploy/harness_ddl.sql. Do NOT use 03_functions_describe.txt — that file is DESCRIBE output (reference only), not CREATE statements. Rewrite `${S}` to <CATALOG>.<SCHEMA> in both SQL files. Test each with CREATE TEMPORARY FUNCTION first. Remember: CREATE OR REPLACE FUNCTION drops grants, so re-run grants after every replace.
VERIFY: run the known answers (handoff section 4). IMPORTANT: all source columns are STRING type (lossless). You MUST cast to DECIMAL:
  `SELECT COUNT(*), SUM(CAST(federal_action_obligation AS DECIMAL(20,2))) FROM <CATALOG>.<SCHEMA>.aircarrier_src_2116_contract_transactions`
  Expected: 948 rows, 4519300323.83.
  `SELECT COUNT(*), SUM(CAST(federal_action_obligation AS DECIMAL(20,2))) FROM <CATALOG>.<SCHEMA>.aircarrier_src_2114_contract_transactions`
  Expected: 927 rows, 4578603345.77.
  A bare SUM on a STRING column returns NULL or errors — that is not a data problem, it is a missing CAST.
  Also check: pdf_pages, pdf_tables and pdf_cells row counts equal _row_counts.json.
CHECKPOINT 2.

PHASE 3 - Workspace code and notebooks
 a. Put source/aircarrier_bundle in the location the Dragon/GitLab process expects (a GitLab repo, a Git folder or a workspace folder; follow Phase 0e). Optionally restore history from reference/aircarrier_bundle_git_history.tar.gz. Do NOT copy reference/bundle_state_this_workspace into any .bundle folder.
 b. Edit databricks.yml: add or complete the `il5` (Advana) target with host, catalog=<CATALOG>, schema=<SCHEMA>, corpus_volume, kb_dir and warehouse_id (pass the id; the lookup by name "Serverless Starter Warehouse" will not exist). Set the model variables to the Phase 0c endpoints and update seed/models.yaml to match. Then run the checks/test_app.py drift check.
 c. Run the offline suites without the live env vars (unset AIRCARRIER_SI_PERSIST, DATABRICKS_WAREHOUSE_ID and AIRCARRIER_DATA_BACKEND): checks/test_app.py, test_work.py, test_si.py, test_harness.py, test_agents.py, test_gate.py, and pytest checks/test_analyst.py. Report pass/fail counts. Fix only real environment differences, and show me each fix.
 d. Import the notebooks/ folder. Every notebook has hardcoded `users.xiaobing_shang1_civ` and `/Volumes/users/xiaobing_shang1_civ/...` references (3–41 per notebook; Harness Agent Grants has 41). Replace all with the Advana catalog, schema and volume paths. Do not run them yet.
CHECKPOINT 3.

PHASE 4 - Jobs (needs approval)
 a. Preferred path: `databricks bundle validate -t il5` and then `bundle deploy -t il5` with the --var overrides, run through the Dragon pipeline or the web terminal, whichever Advana allows. Fallback: create the 6 jobs from platform/jobs/*.json, rewriting the paths to the new bundle root and keeping `--root <bundle files path>` on every task (serverless has no __file__). Skip the 2 MLflow Trace Metrics jobs.
 b. Keep every schedule PAUSED.
 c. Run the ingest job once (ingest, then build_rules, then publish_serving_docs), then tieout once. Report the results.
CHECKPOINT 4.

PHASE 5 - Front Center app through the Dragon pipeline (needs approval)
 a. Run tools/sync_core_to_app.py so that app/ is self-contained (vendored core and _ops). Confirm app/ imports nothing from outside itself.
 b. Vendor the Python dependencies of app/ (requirements) as wheels if Phase 0f found no mirror.
 c. Prepare the Dragon repo or pipeline inputs: app/ + app.yaml + resources. The app needs 5 resources: sql-warehouse (CAN_USE), agent-model (CAN_QUERY), reasoning-model (CAN_QUERY), checker-model (CAN_QUERY), fallback-model (CAN_QUERY). user_api_scopes must include [sql]. The effective scopes in the commercial workspace were [iam.access-control:read, iam.current-user:read, sql].
 d. Set ALL 15 env vars from platform/apps/aircarrier-front-center-dev.ENV_VARS.md with Advana values. Start with AIRCARRIER_SI_PERSIST=memory and AIRCARRIER_DATA_BACKEND=files. Switch to delta and uc only after Phase 6 grants are verified. A deployment without the env vars starts with no warehouse and no models.
 e. After deploy: confirm the active deployment's source snapshot equals app/, and the scan status. Ask me to open /, /work, /position and /rules in a browser, because a notebook token cannot call the app.
CHECKPOINT 5.

PHASE 6 - Grants for the app service principal (needs approval)
Use platform/uc/04_grants_this_workspace.csv only as a PATTERN; the principals there do not exist in Advana. Grant the new app SP: USE CATALOG/USE SCHEMA; SELECT on the 23 aircarrier_v_doc_* views, the srcv_* views and the 4 SI tables (agent_runs, agent_steps, checker_verdicts, proposals) plus MODIFY where SI_PERSIST=delta; READ+WRITE VOLUME on aircarrier_captures; EXECUTE on the tool functions. Do NOT grant the SP authority, decision_attempts, decisions, determinations, metrics, role_map, rule_evals or rule_register_audit: those are read on the user's token. Re-run grants after any CREATE OR REPLACE FUNCTION. Test as a non-owner, not as the owner.
CHECKPOINT 6.

PHASE 7 - MCP servers (optional, needs approval)
Only if Apps or Dragon allow more apps: mcp-aircarrier-docs, mcp-aircarrier-analyst, mcp-aircarrier-ops (app names must start with mcp-).
BEFORE deploying, rewrite the hardcoded schema references in each server (see handoff section 6 for the exact files):
  * mcp-aircarrier-ops: 13 refs in src/mcp_aircarrier_ops/routes.py (table names), data/sources.py (schema constants), app.yaml (schema value), deploy/databricks/grants.sql.
  * mcp-aircarrier-docs: 6 refs in src/mcp_aircarrier_docs/config.py (SCHEMA default, DOCS_VOLUME_ROOTS default), app.yaml (schema value).
  * mcp-aircarrier-analyst: 3 refs in src/core/catalog.py (STORE_SCHEMA default), app.yaml (schema value).
  Alternatively, set the env vars AIRCARRIER_STORE_SCHEMA and DOCS_VOLUME_ROOTS at deploy time to override the defaults (mcp-aircarrier-ops routes.py still needs editing).
Each needs a stateless /mcp route + CORS (already in the code), the warehouse resource and SELECT on its tables. If MCP apps are not allowed, use source/mcp-servers/mcp_local.py in a notebook (in-process, read-only). The probe app, MCP A Creator and the demo servers are optional.

PHASE 7.5 - Skills (optional)
To install the 3 Genie Code user skills, copy skills/<name>/SKILL.md into ~/.assistant/skills/<name>/SKILL.md. But first, rewrite the hardcoded paths in each:
  * Replace `/Workspace/Users/xiaobing.shang1.civ@mail.mil/the-one-hub/the-ops-center/.bundle/aircarrier/dev/files` with the Advana bundle root path.
  * Replace `users.xiaobing_shang1_civ` with <CATALOG>.<SCHEMA> in the SQL examples.
  * Replace `/Volumes/users/xiaobing_shang1_civ/...` with the Advana volume paths.

PHASE 8 - Role map and authority (needs approval)
The work queue applies decisions only for roles in aircarrier_app_authority that have a holder in aircarrier_app_role_map. Ask me who holds PMS379, NAVY_FMO, NAVY_FMC and OUSD_C_FMO in Advana. Insert role_map rows only for named people.

PHASE 9 - Final verification and handoff
Re-run the known answers, the offline suites and a live /ask question ("total obligations on N00024-09-C-2116" should give $4,519,300,323.83 / 948 actions). Run one SI reconcile on 2116 with real models and report the canvas and checker verdicts. Write SETUP_SUMMARY.md: what was deployed, the env values, the grants, open items and blocked items with their owners.

---------------------------------------- PROMPT END ----------------------------------------

Notes for the operator:
* If Advana limits upload size, upload in parts: source/ and platform/ first (small), then data/tables (about 21 MB), then data/volumes (about 158 MB, mostly PDFs and CSVs under aircarrier_artifacts).
* The three Genie Code user skills are included in `skills/`. To install them, copy each `<skill-name>/SKILL.md` into `~/.assistant/skills/<skill-name>/SKILL.md` in the Advana workspace. The connector config (`.mcp_servers.json`) is not included; re-add connectors in Advana.
* The package is split into 7 zip files in `_zips/` (each under 50 MB) for environments with an upload size limit. Unzip them all into the same directory; they overlay without conflicts.
