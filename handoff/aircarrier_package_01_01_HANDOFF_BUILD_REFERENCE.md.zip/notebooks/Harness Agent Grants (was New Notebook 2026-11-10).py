# Databricks notebook source
# DBTITLE 1,Grant harness agent privileges
# MAGIC %sql
# MAGIC GRANT USE SCHEMA ON SCHEMA users.xiaobing_shang1_civ TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_fpds_2114_transactions TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_fpds_2116_transactions TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_file_c_2114 TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_subawards_2114 TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_funding_history TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_jb_ship_cost TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_jb_funding_tranche TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_pdf_pages TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_app_current_rules TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON TABLE users.xiaobing_shang1_civ.aircarrier_app_rule_register TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON TABLE users.xiaobing_shang1_civ.aircarrier_app_exceptions TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON TABLE users.xiaobing_shang1_civ.aircarrier_app_documents TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT EXECUTE ON FUNCTION users.xiaobing_shang1_civ.aircarrier_app_rule_at TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT, MODIFY ON TABLE users.xiaobing_shang1_civ.aircarrier_app_agent_runs TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT, MODIFY ON TABLE users.xiaobing_shang1_civ.aircarrier_app_agent_steps TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT, MODIFY ON TABLE users.xiaobing_shang1_civ.aircarrier_app_checker_verdicts TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT, MODIFY ON TABLE users.xiaobing_shang1_civ.aircarrier_app_proposals TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT, MODIFY ON TABLE users.xiaobing_shang1_civ.aircarrier_app_model_runs TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;

# COMMAND ----------

# DBTITLE 1,Cell 2
# MAGIC %sql
# MAGIC GRANT USE SCHEMA ON SCHEMA users.xiaobing_shang1_civ TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_fpds_2114_transactions TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_fpds_2116_transactions TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_file_c_2114 TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_subawards_2114 TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_funding_history TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_jb_ship_cost TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_jb_funding_tranche TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_srcv_pdf_pages TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON VIEW users.xiaobing_shang1_civ.aircarrier_app_current_rules TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON TABLE users.xiaobing_shang1_civ.aircarrier_app_rule_register TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON TABLE users.xiaobing_shang1_civ.aircarrier_app_exceptions TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT ON TABLE users.xiaobing_shang1_civ.aircarrier_app_documents TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT EXECUTE ON FUNCTION users.xiaobing_shang1_civ.aircarrier_app_rule_at TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT, MODIFY ON TABLE users.xiaobing_shang1_civ.aircarrier_app_agent_runs TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT, MODIFY ON TABLE users.xiaobing_shang1_civ.aircarrier_app_agent_steps TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT, MODIFY ON TABLE users.xiaobing_shang1_civ.aircarrier_app_checker_verdicts TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT, MODIFY ON TABLE users.xiaobing_shang1_civ.aircarrier_app_proposals TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;
# MAGIC GRANT SELECT, MODIFY ON TABLE users.xiaobing_shang1_civ.aircarrier_app_model_runs TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;

# COMMAND ----------

$ws = "/Workspace/Users/xiaobing.shang1.civ@mail.mil/the-one-hub/the-ops-center/.bundle/aircarrier/dev/files"
$repo = "C:\Users\Peter-HP\git\AirCarrier\dbrepo"
$files = "seed/models.yaml","databricks.yml","resources/app.yml",
  "ops/harness/_common.py","ops/harness/orchestrator.py","ops/harness/checker.py",
  "ops/agents/investigator/run.py","core/adapters/commercial/llm.py","core/adapters/commercial/__init__.py",
  "app/api/agent.py","app/api/si/router.py","app/api/si/sdk.py",
  "checks/test_harness.py","checks/test_app.py","checks/test_si.py",
  "docs/MODELS.md","docs/ORCHESTRATION_V2.md"
foreach ($f in $files) { databricks workspace export "$ws/$f" --file "$repo\$f" --format AUTO --overwrite }

# COMMAND ----------

# MAGIC %sql
# MAGIC GRANT SELECT ON TABLE users.xiaobing_shang1_civ.aircarrier_srcv_file_c_2116 
# MAGIC TO `7e1ec6c0-bbe4-43db-a519-1c1fcd99f9c9`;

# COMMAND ----------

# MAGIC %sql
# MAGIC GRANT READ VOLUME, WRITE VOLUME ON VOLUME users.xiaobing_shang1_civ.aircarrier_mcp_probe_runs
# MAGIC   TO `89a35bc5-a29a-44ca-b483-2f648114d2a3`;

# COMMAND ----------

# DBTITLE 1,Grant probe runs volume access
# MAGIC %sql
# MAGIC GRANT READ VOLUME, WRITE VOLUME ON VOLUME users.xiaobing_shang1_civ.aircarrier_mcp_probe_runs TO `89a35bc5-a29a-44ca-b483-2f648114d2a3`
# MAGIC
# MAGIC