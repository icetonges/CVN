"""The corpus, loaded once from Unity Catalog and refreshed on a TTL."""
from __future__ import annotations

import threading
import time

from docs_core.corpus import Corpus
from mcp_aircarrier_docs import config, warehouse
from mcp_aircarrier_docs.warehouse import render as Q

_lock = threading.Lock()
_state: dict = {"corpus": None, "loaded": 0.0, "as_of": None}


def load_rows() -> tuple[list[dict], list[dict]]:
    pages = warehouse.run(Q("SELECT artifact_id, filename, page, text FROM {pages}",
                            tables={"pages": config.PAGES}))
    tables = warehouse.run(Q(
        "SELECT table_id, artifact_id, filename, page, grid_json, title_block, legends, exhibits, "
        "continuation_of, extractor FROM {tables}", tables={"tables": config.TABLES}))
    return pages, tables


def corpus(loader=load_rows) -> Corpus:
    with _lock:
        stale = time.time() - _state["loaded"] > config.CACHE_TTL_S and _state["as_of"] != "fixture"
        if _state["corpus"] is None or stale:
            pages, tables = loader()
            _state["corpus"] = Corpus(pages, tables)
            _state["loaded"] = time.time()
            _state["as_of"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        return _state["corpus"]


def as_of() -> str | None:
    return _state["as_of"]


def set_corpus(c: Corpus) -> None:
    """For tests and stdio runs with fixtures; never expires."""
    with _lock:
        _state.update(corpus=c, loaded=time.time(), as_of="fixture")
