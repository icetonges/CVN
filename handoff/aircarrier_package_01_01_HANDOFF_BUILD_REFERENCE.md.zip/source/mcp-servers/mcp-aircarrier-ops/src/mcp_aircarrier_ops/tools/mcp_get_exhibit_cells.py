"""Get one PDF exhibit table cells record.

Show me the full PDF exhibit table cells record for one identifier.

Source: exhibit_cells (uc_table).
"""

from __future__ import annotations

from typing import Annotated, Any

from fastmcp import FastMCP
from pydantic import Field

from mcp_aircarrier_ops.data import sources
from mcp_aircarrier_ops.data.warehouse import (
    WarehouseError,
    column,
    qualified,
    run_query,
)

TABLE = qualified(
    sources.EXHIBIT_CELLS_CATALOG,
    sources.EXHIBIT_CELLS_SCHEMA,
    sources.EXHIBIT_CELLS_TABLE,
)
COLUMNS = sources.EXHIBIT_CELLS_COLUMNS
AS_OF = sources.EXHIBIT_CELLS_AS_OF


def register(mcp: FastMCP) -> None:
    """Register the mcp_get_exhibit_cells tool with the MCP server."""

    @mcp.tool(
        name="mcp_get_exhibit_cells",
        annotations={
            "title": "Get one PDF exhibit table cells record",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    def mcp_get_exhibit_cells(
        table_id: Annotated[
            str,
            Field(
                description=("Exact table id to fetch."),
            ),
        ],
    ) -> dict[str, Any]:
        """Show me the full PDF exhibit table cells record for one identifier.

        One record is one cell of one PDF table on one page; value verbatim, value_num
        exact decimal string, with row_header, col_header chain and page legends. The
        source refreshes rebuilt on demand when the corpus changes and currently
        reflects 2026-11-08.

        Returns: The matching record, plus the field used to find it. An error with a
        hint when nothing matches.

        Does not cover: Attribute a budget column to a hull (that is the Attributor's
        job and stays DERIVED); Sum total_dollars_obligated or announced modifications
        as obligations; Write to, promote, or edit any table.
        """
        try:
            key_column = column("table_id", COLUMNS)
            sql = (
                f"SELECT * FROM {TABLE} "  # nosemgrep # nosec B608
                f"WHERE {key_column} = ? LIMIT 1"  # nosemgrep
            )
            rows = run_query(sql, [table_id])
        except (ValueError, WarehouseError) as error:
            return {
                "error": str(error),
                "hint": "Check the identifier format and try again.",
            }
        if not rows:
            return {
                "error": f"No record matched {table_id!r}.",
                "hint": (
                    "Identifiers are exact. Call the describe tool "
                    "for the field list and example values."
                ),
                "as_of": AS_OF,
            }
        return {
            "as_of": AS_OF,
            "record": rows[0],
            "fields_used": ["table_id"],
        }
