"""Work register totals.

Give me the totals for Work register: how many records and how much exposure usd m.

Source: work_register (uc_table).
"""

from __future__ import annotations

from typing import Annotated, Any

from fastmcp import FastMCP
from pydantic import Field

from mcp_aircarrier_ops.data import sources
from mcp_aircarrier_ops.data.warehouse import (
    WarehouseError,
    column,
    qualified,
    run_query,
)
from mcp_aircarrier_ops.models import KindValue, OwnerAgentValue

TABLE = qualified(
    sources.WORK_REGISTER_CATALOG,
    sources.WORK_REGISTER_SCHEMA,
    sources.WORK_REGISTER_TABLE,
)
COLUMNS = sources.WORK_REGISTER_COLUMNS
AS_OF = sources.WORK_REGISTER_AS_OF


def register(mcp: FastMCP) -> None:
    """Register the mcp_work_register_totals tool with the MCP server."""

    @mcp.tool(
        name="mcp_work_register_totals",
        annotations={
            "title": "Work register totals",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    def mcp_work_register_totals(
        owner_agent: Annotated[
            OwnerAgentValue,
            Field(
                description=("Narrow results to one owner agent."),
            ),
        ] = OwnerAgentValue.ANY,
        kind: Annotated[
            KindValue,
            Field(
                description=("Narrow results to one kind."),
            ),
        ] = KindValue.ANY,
    ) -> dict[str, Any]:
        """Give me the totals for Work register: how many records and how much exposure
        usd m.

        One record is one work item (kind + ref_id) with its current state and
        owner_agent. The source refreshes each dispatcher tick and currently reflects
        2026-11-08.

        Returns: Record count and the measure's sum, mean, minimum, and maximum for the
        filtered scope.

        Does not cover: Attribute a budget column to a hull (that is the Attributor's
        job and stays DERIVED); Sum total_dollars_obligated or announced modifications
        as obligations; Write to, promote, or edit any table.
        """
        filter_owner_agent = (
            "" if owner_agent is OwnerAgentValue.ANY else owner_agent.value
        )
        filter_kind = "" if kind is KindValue.ANY else kind.value
        clauses: list[str] = []
        params: list[Any] = []
        if filter_owner_agent:
            clauses.append(column("owner_agent", COLUMNS) + " = ?")
            params.append(filter_owner_agent)
        if filter_kind:
            clauses.append(column("kind", COLUMNS) + " = ?")
            params.append(filter_kind)
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        try:
            measure_column = column("exposure_usd_m", COLUMNS)
            sql = (
                f"SELECT COUNT(*) AS record_count, "  # nosemgrep # nosec B608
                f"SUM({measure_column}) AS measure_total, "
                f"AVG({measure_column}) AS measure_mean, "
                f"MIN({measure_column}) AS measure_min, "
                f"MAX({measure_column}) AS measure_max "
                f"FROM {TABLE}{where}"
            )
            rows = run_query(sql, list(params))
        except (ValueError, WarehouseError) as error:
            return {
                "error": str(error),
                "hint": "Drop a filter, or check the period.",
            }
        return {
            "as_of": AS_OF,
            "measure": "exposure_usd_m",
            "totals": rows[0] if rows else {},
            "filters_applied": len(clauses),
        }
