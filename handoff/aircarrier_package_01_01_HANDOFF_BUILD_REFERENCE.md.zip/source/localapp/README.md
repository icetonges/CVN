# Air Carrier, offline

The front centre, running with no workspace, no network and no account.
Built from dbrepo by `tools/build_localapp.py`. Do not edit anything here by
hand: the next rebuild overwrites it. Change `dbrepo/app` and rebuild.

## Two ways to show it

### 1. The real application

```powershell
.\run.ps1
```

Opens http://127.0.0.1:8000. Everything works: all pages, the SVG
charts, the JSON API at /api/docs, insight capture, and knowledge-base
search over the retrieval layer vendored into `app/_ops`.

First run creates `.venv` and installs three packages, which needs network
once. Every run after that is offline. If PowerShell blocks the script, use
`run.bat`.

### 2. No Python at all

Open `static-site\index.html` in any browser. Pages rendered to
files, with working navigation and charts. Nothing to install and nothing to
approve, which is the point: it works on a locked-down machine and from a
USB stick. The static site needs a local rebuild after this copy.

The search box and the capture form are disabled there and say why. They
need the running application.

## What is inside

| Path | What |
|---|---|
| `app/` | the application, identical to what is deployed |
| `app/_ops/` | the retrieval modules, vendored so search works offline |
| `app/data/` | every table the pages read, plus the built knowledge-base index |
| `static-site/` | 17 pages rendered to HTML, plus assets |
| `run.ps1`, `run.bat` | start the application |

No credentials are stored here and nothing reaches out. `AIRCARRIER_DATA_BACKEND`
defaults to `files`, so every figure on every page comes from `app/data`.

## Rebuilding

After any change to `dbrepo/app`:

```powershell
cd ..\dbrepo
python tools\build_localapp.py
```
