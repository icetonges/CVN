@echo off
REM Same as run.ps1, for a machine whose execution policy blocks scripts.
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo First run. Creating .venv and installing fastapi, uvicorn, jinja2.
  python -m venv .venv
  .venv\Scripts\python.exe -m pip install --quiet --upgrade pip
  .venv\Scripts\python.exe -m pip install --quiet -r requirements.txt
)
echo.
echo   Air Carrier, front centre
echo   http://127.0.0.1:8000
echo.
REM Wait for uvicorn to bind before opening the browser.
start "" /min cmd /c "timeout /t 3 >nul & start "" http://127.0.0.1:8000"
cd app
..\.venv\Scripts\python.exe -m uvicorn main:app --host 127.0.0.1 --port 8000
