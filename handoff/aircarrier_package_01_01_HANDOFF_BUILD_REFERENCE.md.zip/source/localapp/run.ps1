<#
    Start the Air Carrier front centre on this machine.

    First run creates a virtual environment beside this script and installs
    three packages, which needs network once. Every run after that is
    offline. Nothing contacts Databricks at any point.
#>
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$venv = Join-Path $PSScriptRoot ".venv"
$py   = Join-Path $venv "Scripts\python.exe"

if (-not (Test-Path $py)) {
    Write-Host "First run. Creating .venv and installing fastapi, uvicorn, jinja2." -ForegroundColor Cyan
    python -m venv $venv
    & $py -m pip install --quiet --upgrade pip
    & $py -m pip install --quiet -r (Join-Path $PSScriptRoot "requirements.txt")
}

Write-Host ""
Write-Host "  Air Carrier, front centre" -ForegroundColor Green
Write-Host "  http://127.0.0.1:8000" -ForegroundColor Green
Write-Host "  Ctrl+C to stop." -ForegroundColor DarkGray
Write-Host ""

# Open the browser a few seconds in, not now. Uvicorn has not bound the
# port yet, and a demo that opens on a connection-refused page has already
# gone wrong in front of the room.
Start-Job { Start-Sleep -Seconds 3; Start-Process "http://127.0.0.1:8000" } | Out-Null

Set-Location (Join-Path $PSScriptRoot "app")
& $py -m uvicorn main:app --host 127.0.0.1 --port 8000
