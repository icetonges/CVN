/* Air Carrier front center. No dependencies. */
(function () {
  "use strict";

  // ---- theme ------------------------------------------------------------
  var KEY = "ac-theme";
  function apply(t) {
    document.documentElement.setAttribute("data-theme", t);
    try { localStorage.setItem(KEY, t); } catch (e) {}
  }
  var saved = null;
  try { saved = localStorage.getItem(KEY); } catch (e) {}
  apply(saved || (window.matchMedia &&
    window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));

  document.addEventListener("click", function (e) {
    var t = e.target.closest("[data-theme-toggle]");
    if (t) {
      apply(document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark");
      return;
    }
    // ---- lightbox -------------------------------------------------------
    var img = e.target.closest("[data-lightbox]");
    if (img) {
      var lb = document.getElementById("lightbox");
      lb.querySelector("img").src = img.getAttribute("data-full") || img.src;
      lb.classList.add("on");
      return;
    }
    if (e.target.closest("#lightbox")) {
      document.getElementById("lightbox").classList.remove("on");
    }
    // ---- filter chips ---------------------------------------------------
    var chip = e.target.closest("[data-filter]");
    if (chip) {
      var scope = chip.closest("[data-filter-scope]") || document;
      scope.querySelectorAll("[data-filter]").forEach(function (c) { c.classList.remove("on"); });
      chip.classList.add("on");
      var want = chip.getAttribute("data-filter");
      var target = document.querySelector(chip.getAttribute("data-target"));
      if (!target) return;
      target.querySelectorAll("[data-tags]").forEach(function (row) {
        var tags = row.getAttribute("data-tags") || "";
        row.classList.toggle("hide", want !== "*" && tags.indexOf(want) === -1);
      });
    }
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      var lb = document.getElementById("lightbox");
      if (lb) lb.classList.remove("on");
    }
  });

  // ---- live search ------------------------------------------------------
  document.addEventListener("input", function (e) {
    var box = e.target.closest("[data-search]");
    if (!box) return;
    var target = document.querySelector(box.getAttribute("data-search"));
    if (!target) return;
    var q = box.value.trim().toLowerCase();
    var n = 0;
    target.querySelectorAll("[data-row]").forEach(function (row) {
      var hit = !q || row.textContent.toLowerCase().indexOf(q) !== -1;
      row.classList.toggle("hide", !hit);
      if (hit) n++;
    });
    var out = document.querySelector(box.getAttribute("data-count"));
    if (out) out.textContent = n;
  });

  // ---- sortable tables --------------------------------------------------
  document.addEventListener("click", function (e) {
    var th = e.target.closest("th[data-sort]");
    if (!th) return;
    var table = th.closest("table");
    var idx = Array.prototype.indexOf.call(th.parentNode.children, th);
    var desc = th.getAttribute("data-dir") !== "desc";
    th.parentNode.querySelectorAll("th").forEach(function (o) { o.removeAttribute("data-dir"); });
    th.setAttribute("data-dir", desc ? "desc" : "asc");
    var body = table.tBodies[0];
    var rows = Array.prototype.slice.call(body.rows);
    rows.sort(function (a, b) {
      var x = a.cells[idx].getAttribute("data-v") || a.cells[idx].textContent;
      var y = b.cells[idx].getAttribute("data-v") || b.cells[idx].textContent;
      var nx = parseFloat(String(x).replace(/[^0-9.\-]/g, ""));
      var ny = parseFloat(String(y).replace(/[^0-9.\-]/g, ""));
      var c = (!isNaN(nx) && !isNaN(ny)) ? nx - ny : String(x).localeCompare(String(y));
      return desc ? -c : c;
    });
    rows.forEach(function (r) { body.appendChild(r); });
  });
})();

/* ---- grouped navigation -------------------------------------------------
   Click to open, not hover. A hover menu opens when someone is on their way
   somewhere else, and on a touch screen it either does nothing or needs two
   taps. Click is unambiguous on both. Escape closes, arrow keys walk the
   items, and focus leaving the group closes it, so the menu is usable
   without a mouse. */
(function () {
  var groups = [].slice.call(document.querySelectorAll('.navgroup'));
  if (!groups.length) return;

  function close(g) {
    g.removeAttribute('data-open');
    var b = g.querySelector('.navtop');
    if (b) b.setAttribute('aria-expanded', 'false');
  }
  function closeAll(except) {
    groups.forEach(function (g) { if (g !== except) close(g); });
  }
  function open(g) {
    closeAll(g);
    g.setAttribute('data-open', '1');
    var b = g.querySelector('.navtop');
    if (b) b.setAttribute('aria-expanded', 'true');
  }

  groups.forEach(function (g) {
    var btn = g.querySelector('.navtop');
    var items = [].slice.call(g.querySelectorAll('.navmenu a'));

    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      if (g.getAttribute('data-open') === '1') { close(g); } else { open(g); }
    });

    btn.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        open(g);
        if (items[0]) items[0].focus();
      }
    });

    g.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { close(g); btn.focus(); return; }
      var i = items.indexOf(document.activeElement);
      if (i === -1) return;
      if (e.key === 'ArrowDown') { e.preventDefault(); (items[i + 1] || items[0]).focus(); }
      if (e.key === 'ArrowUp') { e.preventDefault(); (items[i - 1] || btn).focus(); }
    });

    // Focus leaving the group entirely closes it. Checked on the next tick
    // because at focusout time the new target is not yet focused.
    g.addEventListener('focusout', function () {
      setTimeout(function () {
        if (!g.contains(document.activeElement)) close(g);
      }, 0);
    });
  });

  document.addEventListener('click', function (e) {
    if (!e.target.closest('.navgroup')) closeAll(null);
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeAll(null);
  });
})();

/* ---- contribute: pick a question, then answer it -------------------------
   Clicking a question fills the form and scrolls to it rather than opening a
   modal. A modal hides the question you are answering at the moment you are
   answering it, which is when you most want to reread it. */
(function () {
  var form = document.getElementById('capture');
  if (!form) return;
  var gapField = document.getElementById('f-gap');
  var ctx = document.getElementById('f-context');
  var title = document.getElementById('form-title');
  var status = document.getElementById('f-status');

  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-answer]');
    if (!b) return;
    gapField.value = b.getAttribute('data-answer');
    ctx.style.display = 'block';
    ctx.innerHTML = '<strong>' + b.getAttribute('data-answer') + '</strong> · ' +
      (b.getAttribute('data-q') || '');
    title.textContent = 'Answering ' + b.getAttribute('data-answer');
    document.getElementById('form-card').scrollIntoView({ behavior: 'smooth', block: 'start' });
    setTimeout(function () { document.getElementById('f-body').focus(); }, 320);
  });

  form.addEventListener('reset', function () {
    gapField.value = '';
    ctx.style.display = 'none';
    title.textContent = 'Tell us what you know';
    status.textContent = '';
  });

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var fd = new FormData(form);
    var payload = { kind: 'sme_assertion' };
    fd.forEach(function (v, k) { payload[k] = v; });
    status.textContent = 'sending...';
    fetch('/api/capture', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).then(function (r) { return r.json(); }).then(function (j) {
      // Say exactly what happened. "Thanks!" when nothing was stored is the
      // kind of small lie that stops people contributing a second time.
      if (j.stored) {
        status.textContent = 'Recorded. You will hear back if it closes a question.';
      } else {
        status.textContent = 'Received, and not yet written to the store: the capture '
          + 'writer lands with the Unity Catalog backend. Nothing is lost, but do not '
          + 'rely on this having been saved yet.';
      }
      status.style.color = j.stored ? 'var(--ok)' : 'var(--warn)';
    }).catch(function () {
      status.textContent = 'Could not reach the server. Nothing was sent.';
      status.style.color = 'var(--bad)';
    });
  });
})();

/* ---- knowledge base search ---------------------------------------------- */
(function () {
  var go = document.getElementById('kbgo');
  if (!go) return;
  var q = document.getElementById('kbq');
  var auth = document.getElementById('kbauth');
  var res = document.getElementById('kbres');

  function run() {
    if (!q.value.trim()) return;
    res.innerHTML = '<p class="muted">searching...</p>';
    fetch('/api/search?q=' + encodeURIComponent(q.value) +
          '&authoritative=' + (auth.checked ? 'true' : 'false'))
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (j.error) { res.innerHTML = '<p class="muted">' + j.error + '</p>'; return; }
        if (!j.count) { res.innerHTML = '<p class="muted">Nothing matched.</p>'; return; }
        res.innerHTML = j.hits.map(function (h) {
          return '<div class="kbhit"><span class="cit">' + h.citation +
            ' · ' + h.grade + '</span><p>' +
            h.text.replace(/</g, '&lt;').slice(0, 520) + '…</p></div>';
        }).join('');
      });
  }
  go.addEventListener('click', run);
  q.addEventListener('keydown', function (e) { if (e.key === 'Enter') run(); });
})();
