"""Data access.

Two backends behind one interface, selected by AIRCARRIER_DATA_BACKEND.

  files  JSON bundles in app/data, built by etl/build_data.py. The app runs
         with no workspace at all. This is D11, graceful degradation, applied
         to the front end: the product works at every access level including
         zero.
  uc     named views in the serving schema. The app reads views, never base
         tables, so a new field is a view change rather than a grant change.

Nothing else in the app knows which backend is live.
"""
from __future__ import annotations

import functools
import json
import os
import pathlib

BACKEND = os.environ.get("AIRCARRIER_DATA_BACKEND", "files")
DATA = pathlib.Path(__file__).resolve().parent.parent / "data"
CATALOG = os.environ.get("AIRCARRIER_CATALOG", "aircarrier")
# Mirrors var.schema and var.store_prefix in databricks.yml. The build
# does not create either the catalog or the schema; it is pointed at
# them, and prefixes everything it owns inside.
SCHEMA = os.environ.get("AIRCARRIER_SCHEMA", "default")
STORE_PREFIX = os.environ.get("AIRCARRIER_STORE_PREFIX", "aircarrier_")

VIEWS = {
    "program": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_program",
    "timeline": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_timeline",
    "cost_categories": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_cost_categories",
    "funding_streams": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_funding_streams",
    "anchor_chain": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_anchor_chain",
    "estimate_history": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_estimate_history",
    "cap_history": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_cap_history",
    "contracts": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_contracts",
    "obligations": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_obligations",
    "federal_accounts": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_federal_accounts",
    "subawards": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_subawards",
    "equipment": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_equipment",
    "industrial": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_industrial",
    "attribution": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_attribution",
    "layers": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_layers",
    "variances": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_variances",
    "gaps": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_gaps",
    "clue_map": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_clue_map",
    "asset": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_asset",
    "sources": f"{CATALOG}.{SCHEMA}.{STORE_PREFIX}v_sources",
}


@functools.lru_cache(maxsize=256)
def _read(path: str, _mtime_ns: int):
    """Cached on the file's modification time, so a rebuilt table is picked up
    on the next request and an unchanged one is not re-parsed.

    A plain lru_cache on the name alone holds the first read for the life of
    the process. On a serverless app that process is long lived, so an insight
    captured through the product, or a table rebuilt by the ETL, would never
    appear until someone restarted it, and nothing would look wrong. Found by
    the data disagreeing with the page that rendered it."""
    return json.loads(pathlib.Path(path).read_text())


def get(name: str):
    if BACKEND == "files":
        p = DATA / f"{name}.json"
        if not p.exists():
            return {}
        return _read(str(p), p.stat().st_mtime_ns)
    raise NotImplementedError(
        f"the 'uc' backend is iteration 2. View for {name} is {VIEWS.get(name)}")


def available() -> list[str]:
    return sorted(p.stem for p in DATA.glob("*.json"))


def backend_info() -> dict:
    return {"backend": BACKEND, "tables": len(available()),
            "catalog": CATALOG if BACKEND == "uc" else None}
