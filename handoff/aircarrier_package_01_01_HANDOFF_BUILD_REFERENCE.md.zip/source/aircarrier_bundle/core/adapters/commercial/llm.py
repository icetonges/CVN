"""Unity Gateway through the OpenAI-compatible unified API.

Every call is traced to MLflow. The trace id and prompt version land on the
candidate claim, which is what satisfies D13 with an audit record rather than
a promise: no AI output writes to a trusted table, and every candidate can be
walked back to what the model saw and which prompt produced it.
"""
import os
import pathlib

import yaml

from ...ports.llm import LLMResult

_SEED = pathlib.Path(__file__).resolve().parents[3] / "seed" / "models.yaml"


def _role_map() -> dict:
    with open(_SEED) as f:
        return yaml.safe_load(f)["roles"]


class GatewayLLM:
    def __init__(self):
        from openai import OpenAI  # imported here so core imports stay light
        host = os.environ["DATABRICKS_HOST"].rstrip("/")
        self._client = OpenAI(
            api_key=os.environ.get("DATABRICKS_TOKEN", ""),
            base_url=f"{host}/serving-endpoints",
        )
        self._roles = _role_map()

    def complete(self, system: str, user: str, *, role: str, prompt_version: str,
                 json_schema: dict | None = None, temperature: float | None = None) -> LLMResult:
        cfg = self._roles[role]
        chain = [cfg["primary"], *cfg.get("fallbacks", [])]
        # temperature is omitted unless asked for: GPT-5.5/6.x and Gemini 3.8 reject any
        # non-default value (probed 2026-11-11), so sending it fails the whole chain.
        base: dict = {
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        }
        if temperature is not None:
            base["temperature"] = temperature
        if json_schema is not None:
            base["response_format"] = {"type": "json_schema", "json_schema": json_schema}

        import mlflow
        errors: list[str] = []
        resp = None
        with mlflow.start_span(name=f"llm.{role}") as span:
            span.set_attribute("prompt_version", prompt_version)
            # Fallbacks are tried in order on any endpoint error (403 disabled, 400
            # deprecated, 5xx). The model that answered is recorded on the result and
            # the span, so a candidate never hides which model produced it.
            for model in chain:
                try:
                    resp = self._client.chat.completions.create(model=model, **base)
                    break
                except Exception as exc:  # noqa: BLE001
                    errors.append(f"{model}: {type(exc).__name__}: {str(exc)[:160]}")
            span.set_attribute("model", model if resp is not None else "none")
            span.set_attribute("fallback_errors", errors)
            trace_id = getattr(span, "request_id", None)
        if resp is None:
            raise RuntimeError(f"role {role!r}: every endpoint failed: {errors}")

        return LLMResult(
            text=_text(resp.choices[0].message.content),
            model=model,
            trace_id=trace_id,
            prompt_version=prompt_version,
            usage=getattr(resp, "usage", None).__dict__ if getattr(resp, "usage", None) else {},
        )


def _text(content) -> str:
    """Some endpoints (reasoning models such as Gemini) return a list of typed blocks
    (reasoning, text) instead of a string. Keep only the text blocks."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    out = []
    for b in content:
        if isinstance(b, dict) and b.get("type") == "text":
            out.append(b.get("text", ""))
        elif getattr(b, "type", None) == "text":
            out.append(getattr(b, "text", ""))
    return "".join(out)


def make_llm() -> GatewayLLM:
    return GatewayLLM()
