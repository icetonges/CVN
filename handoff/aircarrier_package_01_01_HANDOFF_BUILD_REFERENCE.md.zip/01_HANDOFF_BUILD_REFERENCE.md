# Air Carrier (CVN-79 cost reconciliation) - Build Reference, Q&A and Troubleshooting

Packaged 2026-11-12 from the commercial workspace dbc-aae0ba16-8727 (workspace id 7474654188777746), owner xiaobing.shang1.civ@mail.mil.
Purpose: the reference for moving the build to Advana FM, for answering questions about it, and for troubleshooting.
The working copies in the commercial workspace were COPIED, not moved, and are unchanged.

Provenance of statements in this file:
* [V] = verified while building this package (counts, file lists, configs read from the live workspace on 2026-11-12).
* [N] = from the build notes kept during the project (deployment records and test runs, 2026-11-07 to 2026-11-12). Re-verify before relying on it.

---

## 1. What the build is

A cost product for CVN-79 (USS John F. Kennedy). It reconciles reported cost (budget justification J-books, SAR/MSAR, GAO/CRS) against recorded obligations (FPDS/USAspending prime transactions, File C federal account funding). The disagreements are the product: each one becomes a variance, gap or exception with a named owner, a cited source and a gated claim. [N]
Sponsor context: brief for the DCFO (SES), 18-21 Nov 2026. The brief's goal is named access to NAVSEA 01 / PEO Carriers. [N, from PLAN.md/HANDOFF.md]

Main parts:
1. **Front Center app** `aircarrier-front-center-dev`: FastAPI + Jinja2 + server-side SVG (no React, no npm). Pages: overview, variances, position (waterfall, reconciliation ladder), baseline, execution, gaps, insight, mission (Kennedy picture), runs (SI run log), work (exception work queue v2 lanes), rules, ask (tool-calling agent).
2. **Ops Center bundle** (Declarative Automation Bundle `aircarrier`): core libraries (ledger, gate, analyst engine, catalog, adapters), ops entry points (jobs), ETL builders, seed rules/models, checks (test suites), deploy SQL, docs.
3. **MCP servers** (Databricks Apps named mcp-*): docs, analyst, ops, plus the MCP A Creator generator, a synthetic probe and two demo servers.
4. **Unity Catalog stores**: 82 managed tables, 38 views, 8 SQL functions and 5 volumes in `users.xiaobing_shang1_civ`, all prefixed `aircarrier_` (plus `mcp_a_creator_*`). [V]
5. **Notebooks**: store builders (PDF tables, source tables, knowledge graph), work register publish, build tracker, harness grants. [V]

---

## 2. Package layout [V]

| Path | Contents |
|---|---|
| `01_HANDOFF_BUILD_REFERENCE.md` | This file |
| `02_ADVANA_GENIE_CODE_SETUP_PROMPT.md` | Step-by-step prompt for Genie Code in Advana FM |
| `MANIFEST.json` | Every file in the package with size and sha256 |
| `source/aircarrier_bundle/` | The bundle's `files/` tree = SOURCE OF TRUTH (app/, core/, ops/, etl/, seed/, checks/, deploy/, docs/, resources/, tools/, mcp/, corpus/, skills/, databricks.yml, HANDOFF.md, README.md). Excluded: `.git` (see reference), `.databricks`, `.pytest_cache`, `.ruff_cache` |
| `source/mcp-servers/` | mcp-aircarrier-docs, mcp-aircarrier-analyst, mcp-aircarrier-ops, aircarrier-mcp-probe, mcp-bakehouse-sales (demo), weather-mcp (demo), mcp_local.py (in-process fallback), test_mcp_local.py, CONNECTOR_RUNBOOK.md |
| `source/mcp-server-creator/` | MCP A Creator (app `mcp-a-creator`), Python package `mcp_server_creator` |
| `source/localapp/` | Local-run copy of the app (rebuilt 2026-11-12, byte-identical to bundle app at that time [N]) |
| `notebooks/` | 5 Air Carrier notebooks + `Harness Agent Grants` (source format, runnable). `notebooks/ipynb/` = Jupyter copies (the workspace converted them to notebooks on write; redundant) |
| `platform/apps/` | For each of 8 apps: `<app>.app.json` (resources, scopes, description) and `<app>.active_deployment.json`. `aircarrier-front-center-dev.ENV_VARS.md` = the 15 env vars with values |
| `platform/jobs/` | Full job settings JSON for the 6 aircarrier jobs + 2 auto-created MLflow trace-metric jobs |
| `platform/alerts/` | Alert `Air Carrier MCP probe - failing or silent` |
| `platform/mlflow/` | Experiment metadata (mcp-a-creator traces) |
| `platform/uc/` | `00_volumes.sql`, `01_tables.sql` (SHOW CREATE TABLE of 82 tables — has 84 hardcoded `users.xiaobing_shang1_civ` refs that MUST be replaced), `02_views.sql` (38 views — 38 hardcoded refs), `03_functions_describe.txt` (8 functions, DESCRIBE FUNCTION EXTENDED — reference only, use `deploy/harness_tools.sql` for CREATE statements), `04_grants_this_workspace.csv` (375 grant rows — SP UUIDs are workspace-specific, use as pattern only), `05_load_tables_from_package.py` (uses INSERT INTO to preserve CHECK constraints; run 01_tables.sql first) |
| `data/tables/` | 80 tables as Parquet + 2 trace tables as JSONL (VARIANT columns), `_row_counts.json` (source rows = exported rows for all 82) |
| `data/volumes/` | Byte copies of 5 volumes: aircarrier_artifacts (200 files, 147.3 MB: corpus PDFs/CSVs, MANIFEST.json), aircarrier_extracted (3 files, 10.0 MB: kb index), mcp_a_creator (117 files), aircarrier_mcp_probe_runs (3 sweep files as of packaging; it is a live log), aircarrier_captures (empty) |
| `reference/aircarrier_bundle_git_history.tar.gz` | The bundle's local `.git` (commits incl. 9bdf7a4, 07e8157, 8e55ebb). Extract with `tar xzf` into the bundle root to restore history |
| `reference/bundle_state_this_workspace/`, `reference/bundle_local_cache_this_workspace/` | Bundle state from THIS workspace. Reference only. Do NOT copy into Advana bundle folders (it points at commercial resource ids) |
| `reference/media/` | CORAS CFO mission module demo video (design reference), ddxtag.png, alert JSON export |

| `skills/` | 3 Genie Code user skills (aircarrier-investigate, aircarrier-verify-figure, aircarrier-collection-request). Install in Advana under `~/.assistant/skills/` |
| `reference/assistant_plans/` | The harness build plan (reference only) |
| `_zips/` | 7 zip files (each under 50 MB) containing the entire package for upload. `_zip_manifest.json` lists them |

Not in the package (and why):
* `.assistant/.mcp_servers.json`: connector configuration. Do not copy; re-add connectors in Advana's Genie Code settings.
* `state/resources.deployment.json`: a BUNDLE_DEPLOYMENT object that cannot be read as a file. It is regenerated by the first `bundle deploy` in Advana.
* Running app containers, SPs, OAuth secrets, warehouse ids, model endpoints: environment objects. They are re-created in Advana.
* `.conversations`, `.db_internal`: workspace UI internals.

---

## 3. Components in detail

### 3.1 Bundle `aircarrier` (source/aircarrier_bundle)
* `databricks.yml`: bundle variables catalog, schema, store_prefix (`aircarrier_`), corpus_volume, kb_dir, warehouse_id (lookup by name "Serverless Starter Warehouse"), the model variables agent/reasoning/checker/fallback/extraction/embedding_model. Targets `dev` (commercial) and `il5` (placeholder). [V]
* `resources/app.yml` (app + 4 serving resources + config.env), `resources/jobs.yml`, `resources/volumes.yml`; `resources-optional/schemas.yml` (seven-schema layout, opt-in). [V]
* `core/`: `ledger.py` (append-only claim ledger keyed by claim_id + version_sha; supersede, withdraw), `catalog.py` (table names), `analyst/` (loa, engine, learn, backtest, residual, sources), `adapters/commercial` and `adapters/il5` (IL5 adapter is a stub by design). [V for files, N for behavior]
* `ops/`: `entrypoints/` (ingest_job, tieout_job, reader_job, eval_job, harness_job, challenger/gate/investigator jobs), `dispatcher/run.py`, `harness/` (orchestrator.run_exception, precheck, evaluate, _common.role_chain). Each entry point takes `--root`. [V]
* `etl/`: build_data.py, build_delivery.py, build_rules.py (generates app/data/rules.json, never hand-edit), publish_serving_docs.py (writes aircarrier_serving_doc + v_doc_ views). [V/N]
* `seed/`: models.yaml (the single source of model routing), gate.yaml, gaps/variances/decisions index YAML. [N]
* `deploy/`: harness DDL, harness_tools.sql (UC tool functions), harness_authority.sql, rule_cc02_v5/v6.sql, Deploy-ToDatabricks.ps1, TRANSFER.md. [V]
* `checks/`: test_app, test_work, test_si, test_harness, test_agents, test_gate, test_analyst (pytest only) and more. [V]
* `docs/`: API_SPEC, ARCHITECTURE, DECISIONS, DEPLOY (includes the GitLab Dragon path), GATE, JBOOK_REFERENCE, MODELS, ORCHESTRATION_V2, RECORD_RECON_DESIGN, UC_SERVING_VIEWS, UX_REVIEW_2026-11-11, WORK_QUEUE_V2, requests/ (drafted, unsent requests: role map for NAVY_FMO/OUSD_C_FMO, CAP-05 baseline figure). [V]

### 3.2 Jobs [V from platform/jobs]
| Job | Entry point | Schedule in dev |
|---|---|---|
| aircarrier ingest | ingest_job.py (`--volume` corpus, `--out` kb) then build_rules.py then publish_serving_docs.py | none (manual) |
| aircarrier tieout | tieout_job.py | PAUSED, daily 11:00 |
| aircarrier rule eval | eval_job.py | PAUSED, daily 12:00 |
| aircarrier harness | harness_job.py | PAUSED, daily 12:30 |
| aircarrier dispatcher | ops/dispatcher/run.py | PAUSED, hourly |
| aircarrier event capture | reader_job.py --handler transaction --source gov-events | PAUSED, daily 06:30 |
All are serverless `spark_python_task`s that run files straight from the bundle folder, so edits to the files take effect without a deploy (sync_mode in-place). [N]
The 2 "Trace Metrics Computation Job"s were auto-created by MLflow for the mcp-a-creator experiments. They don't need migrating.

### 3.3 Apps [V from platform/apps]
| App | Source | Resources | Notes |
|---|---|---|---|
| aircarrier-front-center-dev | bundle files/app | sql-warehouse, agent-model, reasoning-model, checker-model, fallback-model; user_api_scopes [sql] | 15 env vars REQUIRED (see ENV_VARS.md). Active deployment 01f1deb063ca, scan CLEAN |
| mcp-aircarrier-docs | mcp-servers/mcp-aircarrier-docs | sql-warehouse, pdf-pages, pdf-tables (SELECT), artifacts (READ VOLUME) | 11 tools: search, read page, tables, figures, tie-out, parse PDF [N] |
| mcp-aircarrier-analyst | mcp-servers/mcp-aircarrier-analyst | sql-warehouse | 12 tools; src/core is a vendored, hash-checked copy of bundle core/analyst [N] |
| mcp-aircarrier-ops | mcp-servers/mcp-aircarrier-ops | sql_warehouse + 4 tables | 6 read-only tools, generated by MCP A Creator [N] |
| aircarrier-mcp-probe | mcp-servers/aircarrier-mcp-probe | none | Sweeps the 4 MCP apps every 15 min and writes JSONL to the probe volume; the alert reads it |
| mcp-a-creator | mcp-server-creator | warehouse, volume `storage`, experiment, trace tables; scopes sql, workspace.workspace, apps | Generates MCP servers from data |
| mcp-bakehouse-sales, mcp-weather | mcp-servers | demo | Optional, test-only |

### 3.4 Front Center features (in app/)
* Work queue v2 (`/work`): Decide / Unblock / System lanes; exception cards with a code-generated answer line; decisions are applied with on-behalf-of-user (OBO) authority checked server-side against `aircarrier_app_authority` + `aircarrier_app_role_map`. [N]
* SI layer (`app/api/si/`): page-triggered specialists (reconcile_obligations, explain_residual, investigate_gap, brief_readiness), a deterministic canvas check, then a checker from a different model family, then a review modal. Runs persist to the agent_runs, agent_steps, checker_verdicts and proposals tables when AIRCARRIER_SI_PERSIST=delta, in one BEGIN ATOMIC block. [N]
* Rules (`/rules`): reads the rule register live through harness_sql.rule_catalog. Gate routes come from app/data/rules.json. [N]
* Reconciliation ladder (api/ladder.py, 13 rungs), mission finder facets, provenance ids (sha256, 16 hex) with records endpoints. [N]
* Data backend: `AIRCARRIER_DATA_BACKEND=uc` reads the 23 `aircarrier_v_doc_*` views (60 s cache); `files` reads app/data/*.json. [N]
* Security: SQL is built only with app/api/sqlsafe.compose(), never with f-strings. Charts return Markup through @_html. [N]

### 3.5 Unity Catalog stores [V]
Table groups (prefix aircarrier_):
* Source (lossless, verbatim strings + _row_num/_row_sha/_source_locator): src_2114_*, src_2116_*, src_funding_history, src_registry, srcv_file_c_2116; views srcv_*.
* PDF stores: pdf_pages, pdf_tables, pdf_cells; J-book exhibit tables jb_*.
* Claims and gating: claim (ledger), challenge, gate, work, mechanism, prose_notes, question_triage, proposed_gaps, collection_requirements, gaps, variances; views v_review_queue, v_work_queue, v_gaps, v_variances.
* Knowledge graph: kg_nodes, kg_edges.
* Analyst: analyst_runs, analyst_leads, analyst_outcomes.
* App harness: app_agent_runs, app_agent_steps, app_checker_verdicts, app_proposals, app_decisions, app_decision_attempts, app_determinations, app_exceptions, app_rule_register (INSERT-ONLY), app_rule_register_audit, app_rule_evals, app_authority, app_role_map, app_metrics, app_model_runs, app_documents; view app_current_rules.
* Serving: serving_doc + 23 v_doc_* views.
* Test/scratch tables (safe to skip in production): app_probe_txn, app_probe_txn2 and the 12 apptest_* tables.
* Functions (8 total): aircarrier_tool_get_exception, _get_cip_transactions, _get_cost_capture, _get_rule, _get_document_text, _get_evm_control_account, _get_cap_ledger (all 7 in deploy/harness_tools.sql), plus aircarrier_app_rule_at (in deploy/harness_ddl.sql).
* Volumes: aircarrier_artifacts (corpus: one folder per artifact_id = the first 16 hex of the file's sha256, plus MANIFEST.json), aircarrier_extracted (kb), aircarrier_captures, aircarrier_mcp_probe_runs, mcp_a_creator.

### 3.6 Model routing [V databricks.yml, N behavior]
| Role | Primary | Fallbacks | Need |
|---|---|---|---|
| agent | databricks-gpt-5-5 | gemini-3-8-flash, grok-4-7 | function tools on chat completions |
| reasoning | databricks-gpt-6-1-sol | grok-4-7, gemini-3-8-flash | JSON output, no tools |
| checker | databricks-gemini-3-8-flash | grok-4-7 | MUST be a different family from agent/reasoning (rule B28.5) |
| extraction | databricks-gpt-6-sol | gpt-5-6-sol, gemini-3-8-flash | structured extraction |
| embedding | databricks-bge-large-en | | |
The single source is seed/models.yaml; databricks.yml defaults must match it, or checks/test_app.py fails. No Claude endpoints are used (removed 2026-11-11). In Advana, map each role to an endpoint that exists there, then update models.yaml, the databricks.yml defaults and the app env vars together.

---

## 4. Known answers (use these to prove a migration worked) [N, re-verified 2026-11-09]
* N00024-09-C-2116 (CVN-79 construction prep, CP): 948 transaction rows; SUM(federal_action_obligation) as Decimal = $4,519,300,323.83.
* N00024-15-C-2114 (DD&C): 927 rows; SUM = $4,578,603,345.77. Last action_date 2026-07-20.
* Never sum total_dollars_obligated: it is a per-row running total of the award.
* PDF gates: SCN PB27 P-5c N.1 9/9 and Net P-1 490.952; CRS p.14 FY19 11,341.4 / FY26 13,196.0; SCN p90-110 tie-out 72/72.
* Row counts of every table: data/tables/_row_counts.json. 2,005,457 rows across the 80 Parquet tables; 1,848 rows in the 2 JSONL tables; 2,007,305 total across all 82. [V]
* **All source columns are STRING type** (lossless verbatim storage). Verification queries MUST cast to DECIMAL:
  `SELECT COUNT(*), SUM(CAST(federal_action_obligation AS DECIMAL(20,2))) FROM <schema>.aircarrier_src_2116_contract_transactions`
  Expected: 948 rows, 4519300323.83. A bare `SUM(federal_action_obligation)` on a STRING column will silently return NULL or error.
* App /ask on the agent model returned $4,519,300,323.83 / 948. [N]

---

## 5. Identity and grants [V from 04_grants_this_workspace.csv, N for lessons]
* App service principals in this workspace (ids won't carry over): front-center 7e1ec6c0-..., analyst c67f5767-..., creator d817b305-..., ops 720057b7-..., docs c84a4777-..., probe 89a35bc5-....
* The front-center SP has NO SELECT on authority, decision_attempts, decisions, determinations, metrics, role_map, rule_evals or rule_register_audit by design: those are read with the user's token (OBO). It has SELECT on the 23 v_doc_* views and READ+WRITE on aircarrier_captures.
* `CREATE OR REPLACE FUNCTION` DROPS that function's grants. Re-run the GRANT after replacing any tool function.
* The grants CSV also lists another principal (dinne.kopelevich1@cms.hhs.gov) with many grants. Those were inherited in this workspace; do not reproduce them.

---

## 6. Hardcoded references that MUST be rewritten before use [V, from source scan]

The bundle's runtime code (app/, core/) reads catalog, schema and prefix from environment variables and is clean. But deploy scripts, DDL exports, MCP server configs and skills contain hardcoded references to the commercial workspace. A `sed` or find-and-replace is needed before running any of these.

| Artifact | Refs | What to replace |
|---|---|---|
| `platform/uc/01_tables.sql` | 84 | `users.xiaobing_shang1_civ` -> `<CATALOG>.<SCHEMA>` |
| `platform/uc/02_views.sql` | 38 | same |
| `platform/uc/03_functions_describe.txt` | 15 | same (but prefer `deploy/harness_tools.sql` for actual CREATE statements) |
| `source/aircarrier_bundle/deploy/grants_harness_agent.sql` | 65 | `users.xiaobing_shang1_civ` -> target; SP UUID `7e1ec6c0-...` -> new app SP |
| `source/aircarrier_bundle/deploy/grants_front_center.sql` | 30 | same |
| `source/aircarrier_bundle/deploy/harness_authority.sql` | 13 | schema + email (`xiaobing.shang1.civ@mail.mil` -> Advana user) |
| `source/aircarrier_bundle/deploy/harness_ddl.sql` | 2 | comment only (uses `${S}` variable in SQL) |
| `source/aircarrier_bundle/deploy/harness_tools.sql` | 2 | comment only (uses `${S}`) |
| `source/aircarrier_bundle/deploy/seed_rules.py` | 2 | `SCHEMA` default (overridden by env at runtime) |
| `source/mcp-servers/mcp-aircarrier-ops` | 13 | `routes.py` table names; `data/sources.py` schema constants; `app.yaml` schema value; `deploy/grants.sql` |
| `source/mcp-servers/mcp-aircarrier-docs` | 6 | `config.py` SCHEMA default + DOCS_VOLUME_ROOTS default; `app.yaml` schema value |
| `source/mcp-servers/mcp-aircarrier-analyst` | 3 | `src/core/catalog.py` STORE_SCHEMA default; `app.yaml` schema value |
| `skills/` (all 3) | 8 total | Bundle root path, `users.xiaobing_shang1_civ` table refs |
| `notebooks/` (all 6) | 3–41 each | `users.xiaobing_shang1_civ` and `/Volumes/users/xiaobing_shang1_civ/...`; Harness Agent Grants has 41 (grant statements with SP UUIDs) |
| `source/aircarrier_bundle/deploy/Deploy-ToDatabricks.ps1` | 3 | workspace URL `dbc-aae0ba16-8727` |

The app itself (app/api/live.py) reads `AIRCARRIER_CATALOG`, `AIRCARRIER_SCHEMA`, `AIRCARRIER_STORE_PREFIX` from env vars and has zero hardcoded schema references. The `resources/jobs.yml` file is also clean (uses bundle variable substitution).

The MCP servers use env vars with hardcoded defaults: `mcp-aircarrier-docs` config.py reads `AIRCARRIER_STORE_SCHEMA` (default `users.xiaobing_shang1_civ`), `mcp-aircarrier-analyst` reads the same, and `mcp-aircarrier-ops` has table names baked into routes.py. Set the env vars or edit the defaults.

---

## 7. Dependencies [V]

The app's `app/requirements.txt` pins: fastapi==0.115.6, uvicorn[standard]==0.34.0, jinja2==3.1.5, databricks-sdk==0.40.0, pyyaml==6.0.2. These must be available at app build time. In Advana (no PyPI), vendor the wheels or use an internal mirror.

The bundle's `pyproject.toml` lists runtime deps: openai>=1.0, mlflow>=3.0, databricks-sdk>=0.40, pyyaml>=6.0, pydantic>=2.0. The MCP servers need fastmcp>=2.14,<3. The store-builder notebooks need pypdf, pdfplumber, openpyxl.

There is no `uv.lock` in the package. The bundle docs say uv manages the lock, but no lock file was committed. On first deploy in Advana, pin the versions you resolve.

---

## 8. TBLPROPERTIES portability note [V]

The DDL in `01_tables.sql` carries every TBLPROPERTIES key from the commercial workspace, including auto-set Delta feature flags. Some may not exist on the Advana runtime:
* `delta.feature.variantShredding-preview` and `delta.feature.variantType-preview`: only on the MLflow trace tables (`mcp_a_creator_otel_*`). If the Advana runtime doesn't support these, remove the TBLPROPERTIES block from those two CREATE statements and load via JSONL instead.
* 7 CHECK constraints (verdict_enum, action_enum, citation_complete, status_enum, attempt_action, owner_office_nonempty, always_fail) are critical and must survive. The loader script uses INSERT INTO (not overwrite) specifically to preserve them.
* `delta.enableChangeDataFeed` is on some tables. If CDF is not supported, remove it.

---

## 9. Status as of 2026-11-12 [N]
* Live: app running with uc backend and 15 env vars; MCP docs/analyst/ops running; probe sweeping (first sweep 16:42Z, all green).
* Ledger: 11,632 active exhibit claims; 13 promoted claims (zone V); 19 CVN-79 claims are candidates. 397 Hull Number claims withdrawn. Review queue 11,651.
* Decisions: 2 (one applied, one rejected). 0 open real exceptions (the seed exceptions are void_test_data or superseded).
* Open items: roles NAVY_FMO and OUSD_C_FMO have no holder; window_days values are not set; reader unit-default decision; analyst engine needs labeled periods (no skill shown over baseline yet); IL5 adapter is a stub; WQ2 escalation-as-field, sponsor line and T-tests are not built; precheck G-d is not built.
* Drafted requests (not sent): docs/requests/ROLE_MAP_NAVY_FMO_OUSD_C_FMO.md and CAP05_BASELINE_FIGURE.md.

---

## 10. Q&A and troubleshooting

**Q: The app starts but /work says "no SQL warehouse is bound (DATABRICKS_WAREHOUSE_ID is unset)" and agent runs say "live read is not available".**
The deployment was made without env vars. A REST `POST /apps/<name>/deployments` does NOT carry the previous env vars forward, and neither does a stop/start. Redeploy with all 15 (platform/apps/aircarrier-front-center-dev.ENV_VARS.md), or deploy through the bundle, which sets them from resources/app.yml config.env.

**Q: I deployed the bundle but the app still serves old pages (or TemplateNotFound).**
`bundle deploy` uploads files but does not redeploy the app. Run `databricks bundle run aircarrier_front_center -t <target> <same --var flags>` after every deploy. `apps start` on a running app does nothing.

**Q: A serverless job fails at import with NameError `__file__`.**
Serverless exec()s the file. Every entry point must get `--root ${workspace.file_path}`; add it to any new entry point in resources/jobs.yml.

**Q: The bundle deploy fails with CATALOG_DOES_NOT_EXIST or 403 on CREATE SCHEMA.**
The bundle never creates the catalog or schema. Pass `--var catalog=<existing> --var schema=<existing writable>`. The defaults (catalog `aircarrier`, schema `default`) do not exist. In dev the working overrides were catalog=users, schema=xiaobing_shang1_civ, corpus_volume=/Volumes/users/xiaobing_shang1_civ/aircarrier_artifacts and kb_dir=/Volumes/users/xiaobing_shang1_civ/aircarrier_extracted/kb.

**Q: An Apps PATCH wiped my resources, description or scopes.**
The Apps PATCH replaces every field it is sent and clears the omitted mutable fields. Always send description + resources + user_api_scopes together.

**Q: /work fails with INSUFFICIENT_PERMISSIONS.**
The app SP is reading a table it has no grant on. Those tables must be read on the user token. Test as a non-owner: a test run as the owner hides SP grant gaps.

**Q: An SI run button returns 403.**
The origin check: behind the Apps proxy, Host is internal. router._hosts() accepts X-Forwarded-Host and DATABRICKS_APP_URL, and the 403 text names both hosts.

**Q: An SI run page returns 404 after an app restart.**
Fixed: store.load_run rebuilds a run from the 4 tables. If it still fails, check the SP has SELECT on agent_runs, agent_steps, checker_verdicts and proposals.

**Q: SI writes fail on constraints.**
agent_steps CHECK citation_complete requires agent_name 'orchestrator' or rule_id + rule_version + record_ids; inputs_digest is NOT NULL. checker_verdicts verdict must be pass, pass_with_exception or fail. EXPLAIN does not test CHECK constraints. Test on scratch tables built from SHOW CREATE TABLE (shallow clones fail with BEGIN ATOMIC).

**Q: get_rule returns not_found.**
current_rules lists only the active versions. get_rule(version NULL) falls back to the latest version with its status. rule_register is INSERT-ONLY: retire a version with a 'retire' audit event; never UPDATE it.

**Q: The MCP connectors show "Failed to generate OAuth token".**
This is client-side connector auth. The user re-authenticates each connector in Genie Code Settings > Connectors. Meanwhile use mcp-servers/mcp_local.py (in-process, read-only). See CONNECTOR_RUNBOOK.md.

**Q: A model call fails with 403, or tools are refused.**
The endpoint is disabled, or the model refuses function tools while reasoning is on (gpt-6.x). gpt-5-5 and gemini reject non-default temperature. Map the roles to available endpoints and keep the checker in a different family.

**Q: The YAML topics are truncated.**
Flow maps with unquoted commas. The seed files are already quoted; keep quoting.

**Q: Spark SQL drops a quote.**
Inside a literal, '' drops the quote; avoid it. A SQL UDF parameter can only be referenced in WHERE, not in a subquery's SELECT/ORDER BY.

**Q: How do I rebuild the stores from the raw corpus instead of loading Parquet?**
Run the notebooks in order: Source Table Store Build, PDF Table Store Build, then Knowledge Graph Build. Each has assert gates (the known answers in section 4). Then run the ingest job (kb + rules.json + serving docs). Serverless needs `pip install pypdf pdfplumber openpyxl`, and in Advana those must come from an internal mirror or vendored wheels.

**Q: Which copy is authoritative?**
The bundle folder (source/aircarrier_bundle). The local repo C:\Users\Peter-HP\git\AirCarrier\dbrepo is behind it.

**Q: Exhibit claims show UNKNOWN units.**
1,778 remain (1,556 on P-29/P-30), and those exhibits print no unit word. A cited unit-default rule is needed. Don't re-run the J-book extraction casually: the extraction method is part of version_sha, so a re-run churns 11,632 claim versions.
