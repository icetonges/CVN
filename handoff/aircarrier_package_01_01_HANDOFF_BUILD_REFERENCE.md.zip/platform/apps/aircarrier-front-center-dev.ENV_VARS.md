# aircarrier-front-center env vars (all 15 are REQUIRED on every REST deployment)

The Apps API does not return values; these come from the deployment record of 01f1deb063ca16d7ad79d460eaeedf22 (2026-11-12). No secrets.

| Name | Value in commercial dev | Advana value |
|---|---|---|
| AIRCARRIER_CATALOG | `users` | <advana catalog> |
| AIRCARRIER_SCHEMA | `xiaobing_shang1_civ` | <advana schema> |
| AIRCARRIER_STORE_PREFIX | `aircarrier_` | aircarrier_ |
| AIRCARRIER_DATA_BACKEND | `uc` | uc (fallback: files) |
| AIRCARRIER_ADAPTER | `commercial` | il5 once core/adapters/il5 is implemented; commercial until then |
| AIRCARRIER_KB_DIR | `/Volumes/users/xiaobing_shang1_civ/aircarrier_extracted/kb` | /Volumes/<cat>/<schema>/aircarrier_extracted/kb |
| DATABRICKS_WAREHOUSE_ID | `value_from: sql-warehouse` | value_from: sql-warehouse (app resource) |
| AIRCARRIER_SI_PERSIST | `delta` | memory first, delta after grants verified |
| AIRCARRIER_AGENT_MODEL | `databricks-gpt-5-5` | <endpoint available in Advana that supports function tools> |
| AIRCARRIER_AGENT_FALLBACKS | `databricks-gemini-3-8-flash,databricks-grok-4-7` | <comma list> |
| AIRCARRIER_REASONING_MODEL | `databricks-gpt-6-1-sol` | <JSON-capable endpoint> |
| AIRCARRIER_REASONING_FALLBACKS | `databricks-grok-4-7,databricks-gemini-3-8-flash` | <comma list> |
| AIRCARRIER_CHECKER_MODEL | `databricks-gemini-3-8-flash` | <different model family than agent/reasoning> |
| AIRCARRIER_CHECKER_FALLBACKS | `databricks-grok-4-7` | <comma list> |
| AIRCARRIER_CAPTURE_VOLUME | `/Volumes/users/xiaobing_shang1_civ/aircarrier_captures` | /Volumes/<cat>/<schema>/aircarrier_captures |
