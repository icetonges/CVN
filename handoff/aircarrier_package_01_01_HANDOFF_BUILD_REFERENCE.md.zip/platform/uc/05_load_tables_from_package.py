"""Load package/data/tables/*.parquet (and *.jsonl) into a target schema.

PREREQUISITES (run in order):
  1. 01_tables.sql  -- creates tables with CHECK/NOT NULL constraints
  2. This script    -- inserts data into those tables
  3. 02_views.sql   -- creates views that read the tables

IMPORTANT: This script uses INSERT INTO (not overwrite) so that the DDL
constraints from step 1 are preserved. If a table already has rows, it
TRUNCATEs first. If the DDL hasn't been run and the table doesn't exist,
it falls back to saveAsTable (no constraints).

NOTE ON TYPES: The source tables store all values as STRING (lossless).
The DDL from 01_tables.sql defines them as STRING too. Do NOT alter
column types. Verification queries must CAST to DECIMAL, e.g.:
  SUM(CAST(federal_action_obligation AS DECIMAL(20,2)))

Usage: set SRC, TARGET, SKIP_PATTERNS, then run in a Databricks notebook.
"""
import json, os

# --- CONFIGURE THESE ---
SRC = "/Volumes/<catalog>/<schema>/<staging_volume>/package/data/tables"
TARGET = "<catalog>.<schema>"  # must match the schema used in 01_tables.sql
SKIP_PATTERNS = []  # e.g. ["apptest_", "app_probe_txn"] to skip scratch tables
# -----------------------

counts = json.load(open(os.path.join(SRC, "_row_counts.json")))
report = []
skipped = []

for name, c in sorted(counts.items()):
    if any(pat in name for pat in SKIP_PATTERNS):
        skipped.append(name)
        continue

    fqn = f"{TARGET}.{name}"
    p = os.path.join(SRC, name + (".jsonl" if "jsonl_rows" in c else ".parquet"))

    # Read source data
    if p.endswith(".parquet"):
        import pandas as pd
        src_df = spark.createDataFrame(pd.read_parquet(p))
    else:
        src_df = spark.read.json(p)

    # Check if the table was created by DDL (has constraints)
    table_exists = spark.catalog.tableExists(fqn)

    if table_exists:
        # Preserve DDL constraints: truncate then insert
        spark.sql(f"TRUNCATE TABLE {fqn}")
        src_df.write.mode("append").insertInto(fqn, overwrite=False)
    else:
        # No DDL was run; create from data (no constraints)
        src_df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(fqn)

    got = spark.table(fqn).count()
    want = c.get("source_rows")
    report.append((name, want, got, want == got))

bad = [r for r in report if not r[3]]
print(f"{len(report)} tables loaded; {len(skipped)} skipped; {len(bad)} row-count mismatches")
if bad:
    print("MISMATCHES:", bad)
if skipped:
    print("SKIPPED:", skipped)

# Spot-check a constraint survived
try:
    ddl = spark.sql(f"SHOW CREATE TABLE {TARGET}.aircarrier_app_checker_verdicts").collect()[0][0]
    has_check = "verdict_enum" in ddl
    print(f"Constraint check: aircarrier_app_checker_verdicts verdict_enum constraint {'PRESENT' if has_check else 'MISSING (DDL was not run first!)'}")
except Exception:
    pass  # table may have been skipped
