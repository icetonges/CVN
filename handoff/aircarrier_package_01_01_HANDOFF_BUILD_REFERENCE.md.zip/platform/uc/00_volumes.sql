CREATE VOLUME IF NOT EXISTS <catalog>.<schema>.mcp_a_creator;
CREATE VOLUME IF NOT EXISTS <catalog>.<schema>.aircarrier_captures;
CREATE VOLUME IF NOT EXISTS <catalog>.<schema>.aircarrier_extracted;
CREATE VOLUME IF NOT EXISTS <catalog>.<schema>.aircarrier_mcp_probe_runs;
CREATE VOLUME IF NOT EXISTS <catalog>.<schema>.aircarrier_artifacts;
