-- Views: run after tables and data load. Where a view reads another view, run it after that one.

-- aircarrier_app_current_rules
CREATE VIEW xiaobing_shang1_civ.aircarrier_app_current_rules (
  rule_id,
  version,
  effective_from,
  effective_to,
  owner_role,
  statement_text,
  expression_sql,
  params,
  value_lists,
  status,
  created_by,
  created_at,
  owner_office,
  required_action,
  area,
  blocked_reason)
WITH SCHEMA COMPENSATION
AS SELECT r.* FROM users.xiaobing_shang1_civ.aircarrier_app_rule_register r
WHERE r.status = 'active'
  AND r.effective_from <= current_timestamp()
  AND (r.effective_to IS NULL OR r.effective_to > current_timestamp())
  AND NOT EXISTS (SELECT 1 FROM users.xiaobing_shang1_civ.aircarrier_app_rule_register n
                  WHERE n.rule_id = r.rule_id AND n.version > r.version
                    AND n.effective_from <= current_timestamp())
;

-- aircarrier_srcv_file_c_2114
CREATE VIEW xiaobing_shang1_civ.aircarrier_srcv_file_c_2114 (
  owning_agency_name,
  reporting_agency_name,
  submission_period,
  allocation_transfer_agency_identifier_code,
  agency_identifier_code,
  beginning_period_of_availability,
  ending_period_of_availability,
  availability_type_code,
  main_account_code,
  sub_account_code,
  treasury_account_symbol,
  treasury_account_name,
  agency_identifier_name,
  allocation_transfer_agency_identifier_name,
  budget_function,
  budget_subfunction,
  federal_account_symbol,
  federal_account_name,
  program_activity_reporting_key,
  program_activity_code,
  program_activity_name,
  object_class_code,
  object_class_name,
  direct_or_reimbursable_funding_source,
  disaster_emergency_fund_code,
  disaster_emergency_fund_name,
  transaction_obligated_amount,
  gross_outlay_amount_fyb_to_period_end,
  ussgl487200_downward_adj_prior_year_prepaid_undeliv_order_oblig,
  ussgl497200_downward_adj_of_prior_year_paid_deliv_orders_oblig,
  award_unique_key,
  award_id_piid,
  parent_award_id_piid,
  award_id_fain,
  award_id_uri,
  award_base_action_date,
  award_base_action_date_fiscal_year,
  award_latest_action_date,
  award_latest_action_date_fiscal_year,
  period_of_performance_start_date,
  period_of_performance_current_end_date,
  ordering_period_end_date,
  award_type_code,
  award_type,
  idv_type_code,
  idv_type,
  prime_award_base_transaction_description,
  awarding_agency_code,
  awarding_agency_name,
  awarding_subagency_code,
  awarding_subagency_name,
  awarding_office_code,
  awarding_office_name,
  funding_agency_code,
  funding_agency_name,
  funding_sub_agency_code,
  funding_sub_agency_name,
  funding_office_code,
  funding_office_name,
  recipient_uei,
  recipient_duns,
  recipient_name,
  recipient_name_raw,
  recipient_parent_uei,
  recipient_parent_duns,
  recipient_parent_name,
  recipient_parent_name_raw,
  recipient_country,
  recipient_state,
  recipient_county,
  recipient_city,
  prime_award_summary_recipient_cd_original,
  prime_award_summary_recipient_cd_current,
  recipient_zip_code,
  primary_place_of_performance_country,
  primary_place_of_performance_state,
  primary_place_of_performance_county,
  prime_award_summary_place_of_performance_cd_original,
  prime_award_summary_place_of_performance_cd_current,
  primary_place_of_performance_zip_code,
  cfda_number,
  cfda_title,
  product_or_service_code,
  product_or_service_code_description,
  naics_code,
  naics_description,
  national_interest_action_code,
  national_interest_action,
  usaspending_permalink,
  last_modified_date,
  _artifact_id,
  _row_num,
  _row_sha,
  _source_locator)
COMMENT 'Read-only. USAspending File C federal account funding, 15-C-2114.'
WITH SCHEMA COMPENSATION
AS SELECT * FROM users.xiaobing_shang1_civ.aircarrier_src_2114_federal_account_funding
;

-- aircarrier_srcv_fpds_2114_transactions
CREATE VIEW xiaobing_shang1_civ.aircarrier_srcv_fpds_2114_transactions (
  contract_transaction_unique_key,
  contract_award_unique_key,
  award_id_piid,
  modification_number,
  transaction_number,
  parent_award_agency_id,
  parent_award_agency_name,
  parent_award_id_piid,
  parent_award_modification_number,
  federal_action_obligation,
  total_dollars_obligated,
  total_outlayed_amount_for_overall_award,
  base_and_exercised_options_value,
  current_total_value_of_award,
  base_and_all_options_value,
  potential_total_value_of_award,
  disaster_emergency_fund_codes_for_overall_award,
  outlayed_amount_from_covid_19_supplementals_for_overall_award,
  obligated_amount_from_covid_19_supplementals_for_overall_award,
  outlayed_amount_from_iija_supplemental_for_overall_award,
  obligated_amount_from_iija_supplemental_for_overall_award,
  action_date,
  action_date_fiscal_year,
  period_of_performance_start_date,
  period_of_performance_current_end_date,
  period_of_performance_potential_end_date,
  ordering_period_end_date,
  solicitation_date,
  awarding_agency_code,
  awarding_agency_name,
  awarding_sub_agency_code,
  awarding_sub_agency_name,
  awarding_office_code,
  awarding_office_name,
  funding_agency_code,
  funding_agency_name,
  funding_sub_agency_code,
  funding_sub_agency_name,
  funding_office_code,
  funding_office_name,
  treasury_accounts_funding_this_award,
  federal_accounts_funding_this_award,
  object_classes_funding_this_award,
  program_activities_funding_this_award,
  foreign_funding,
  foreign_funding_description,
  sam_exception,
  sam_exception_description,
  recipient_uei,
  recipient_duns,
  recipient_name,
  recipient_name_raw,
  recipient_doing_business_as_name,
  cage_code,
  recipient_parent_uei,
  recipient_parent_duns,
  recipient_parent_name,
  recipient_parent_name_raw,
  recipient_country_code,
  recipient_country_name,
  recipient_address_line_1,
  recipient_address_line_2,
  recipient_city_name,
  prime_award_transaction_recipient_county_fips_code,
  recipient_county_name,
  prime_award_transaction_recipient_state_fips_code,
  recipient_state_code,
  recipient_state_name,
  recipient_zip_4_code,
  prime_award_transaction_recipient_cd_original,
  prime_award_transaction_recipient_cd_current,
  recipient_phone_number,
  recipient_fax_number,
  primary_place_of_performance_country_code,
  primary_place_of_performance_country_name,
  primary_place_of_performance_city_name,
  prime_award_transaction_place_of_performance_county_fips_code,
  primary_place_of_performance_county_name,
  prime_award_transaction_place_of_performance_state_fips_code,
  primary_place_of_performance_state_code,
  primary_place_of_performance_state_name,
  primary_place_of_performance_zip_4,
  prime_award_transaction_place_of_performance_cd_original,
  prime_award_transaction_place_of_performance_cd_current,
  award_or_idv_flag,
  award_type_code,
  award_type,
  idv_type_code,
  idv_type,
  multiple_or_single_award_idv_code,
  multiple_or_single_award_idv,
  type_of_idc_code,
  type_of_idc,
  type_of_contract_pricing_code,
  type_of_contract_pricing,
  transaction_description,
  prime_award_base_transaction_description,
  action_type_code,
  action_type,
  solicitation_identifier,
  number_of_actions,
  inherently_governmental_functions,
  inherently_governmental_functions_description,
  product_or_service_code,
  product_or_service_code_description,
  contract_bundling_code,
  contract_bundling,
  dod_claimant_program_code,
  dod_claimant_program_description,
  naics_code,
  naics_description,
  recovered_materials_sustainability_code,
  recovered_materials_sustainability,
  domestic_or_foreign_entity_code,
  domestic_or_foreign_entity,
  dod_acquisition_program_code,
  dod_acquisition_program_description,
  information_technology_commercial_item_category_code,
  information_technology_commercial_item_category,
  epa_designated_product_code,
  epa_designated_product,
  country_of_product_or_service_origin_code,
  country_of_product_or_service_origin,
  place_of_manufacture_code,
  place_of_manufacture,
  subcontracting_plan_code,
  subcontracting_plan,
  extent_competed_code,
  extent_competed,
  solicitation_procedures_code,
  solicitation_procedures,
  type_of_set_aside_code,
  type_of_set_aside,
  evaluated_preference_code,
  evaluated_preference,
  research_code,
  research,
  fair_opportunity_limited_sources_code,
  fair_opportunity_limited_sources,
  other_than_full_and_open_competition_code,
  other_than_full_and_open_competition,
  number_of_offers_received,
  commercial_item_acquisition_procedures_code,
  commercial_item_acquisition_procedures,
  small_business_competitiveness_demonstration_program,
  simplified_procedures_for_certain_commercial_items_code,
  simplified_procedures_for_certain_commercial_items,
  a76_fair_act_action_code,
  a76_fair_act_action,
  fed_biz_opps_code,
  fed_biz_opps,
  local_area_set_aside_code,
  local_area_set_aside,
  price_evaluation_adjustment_preference_percent_difference,
  clinger_cohen_act_planning_code,
  clinger_cohen_act_planning,
  materials_supplies_articles_equipment_code,
  materials_supplies_articles_equipment,
  labor_standards_code,
  labor_standards,
  construction_wage_rate_requirements_code,
  construction_wage_rate_requirements,
  interagency_contracting_authority_code,
  interagency_contracting_authority,
  other_statutory_authority,
  program_acronym,
  parent_award_type_code,
  parent_award_type,
  parent_award_single_or_multiple_code,
  parent_award_single_or_multiple,
  major_program,
  national_interest_action_code,
  national_interest_action,
  cost_or_pricing_data_code,
  cost_or_pricing_data,
  cost_accounting_standards_clause_code,
  cost_accounting_standards_clause,
  government_furnished_property_code,
  government_furnished_property,
  sea_transportation_code,
  sea_transportation,
  undefinitized_action_code,
  undefinitized_action,
  consolidated_contract_code,
  consolidated_contract,
  performance_based_service_acquisition_code,
  performance_based_service_acquisition,
  multi_year_contract_code,
  multi_year_contract,
  contract_financing_code,
  contract_financing,
  purchase_card_as_payment_method_code,
  purchase_card_as_payment_method,
  contingency_humanitarian_or_peacekeeping_operation_code,
  contingency_humanitarian_or_peacekeeping_operation,
  alaskan_native_corporation_owned_firm,
  american_indian_owned_business,
  indian_tribe_federally_recognized,
  native_hawaiian_organization_owned_firm,
  tribally_owned_firm,
  veteran_owned_business,
  service_disabled_veteran_owned_business,
  woman_owned_business,
  women_owned_small_business,
  economically_disadvantaged_women_owned_small_business,
  joint_venture_women_owned_small_business,
  joint_venture_economic_disadvantaged_women_owned_small_bus,
  minority_owned_business,
  subcontinent_asian_asian_indian_american_owned_business,
  asian_pacific_american_owned_business,
  black_american_owned_business,
  hispanic_american_owned_business,
  native_american_owned_business,
  other_minority_owned_business,
  contracting_officers_determination_of_business_size,
  contracting_officers_determination_of_business_size_code,
  emerging_small_business,
  community_developed_corporation_owned_firm,
  labor_surplus_area_firm,
  us_federal_government,
  federally_funded_research_and_development_corp,
  federal_agency,
  us_state_government,
  us_local_government,
  city_local_government,
  county_local_government,
  inter_municipal_local_government,
  local_government_owned,
  municipality_local_government,
  school_district_local_government,
  township_local_government,
  us_tribal_government,
  foreign_government,
  organizational_type,
  corporate_entity_not_tax_exempt,
  corporate_entity_tax_exempt,
  partnership_or_limited_liability_partnership,
  sole_proprietorship,
  small_agricultural_cooperative,
  international_organization,
  us_government_entity,
  community_development_corporation,
  domestic_shelter,
  educational_institution,
  foundation,
  hospital_flag,
  manufacturer_of_goods,
  veterinary_hospital,
  hispanic_servicing_institution,
  receives_contracts,
  receives_financial_assistance,
  receives_contracts_and_financial_assistance,
  airport_authority,
  council_of_governments,
  housing_authorities_public_tribal,
  interstate_entity,
  planning_commission,
  port_authority,
  transit_authority,
  subchapter_scorporation,
  limited_liability_corporation,
  foreign_owned,
  for_profit_organization,
  nonprofit_organization,
  other_not_for_profit_organization,
  the_ability_one_program,
  private_university_or_college,
  state_controlled_institution_of_higher_learning,
  c_1862_land_grant_college,
  c_1890_land_grant_college,
  c_1994_land_grant_college,
  minority_institution,
  historically_black_college,
  tribal_college,
  alaskan_native_servicing_institution,
  native_hawaiian_servicing_institution,
  school_of_forestry,
  veterinary_college,
  dot_certified_disadvantage,
  self_certified_small_disadvantaged_business,
  small_disadvantaged_business,
  c8a_program_participant,
  historically_underutilized_business_zone_hubzone_firm,
  sba_certified_8a_joint_venture,
  highly_compensated_officer_1_name,
  highly_compensated_officer_1_amount,
  highly_compensated_officer_2_name,
  highly_compensated_officer_2_amount,
  highly_compensated_officer_3_name,
  highly_compensated_officer_3_amount,
  highly_compensated_officer_4_name,
  highly_compensated_officer_4_amount,
  highly_compensated_officer_5_name,
  highly_compensated_officer_5_amount,
  usaspending_permalink,
  initial_report_date,
  last_modified_date,
  _artifact_id,
  _row_num,
  _row_sha,
  _source_locator)
COMMENT 'Read-only. USAspending/FPDS prime transactions, N00024-15-C-2114 (DD&C).'
WITH SCHEMA COMPENSATION
AS SELECT * FROM users.xiaobing_shang1_civ.aircarrier_src_2114_contract_transactions
;

-- aircarrier_srcv_fpds_2116_transactions
CREATE VIEW xiaobing_shang1_civ.aircarrier_srcv_fpds_2116_transactions (
  contract_transaction_unique_key,
  contract_award_unique_key,
  award_id_piid,
  modification_number,
  transaction_number,
  parent_award_agency_id,
  parent_award_agency_name,
  parent_award_id_piid,
  parent_award_modification_number,
  federal_action_obligation,
  total_dollars_obligated,
  total_outlayed_amount_for_overall_award,
  base_and_exercised_options_value,
  current_total_value_of_award,
  base_and_all_options_value,
  potential_total_value_of_award,
  disaster_emergency_fund_codes_for_overall_award,
  outlayed_amount_from_covid_19_supplementals_for_overall_award,
  obligated_amount_from_covid_19_supplementals_for_overall_award,
  outlayed_amount_from_iija_supplemental_for_overall_award,
  obligated_amount_from_iija_supplemental_for_overall_award,
  action_date,
  action_date_fiscal_year,
  period_of_performance_start_date,
  period_of_performance_current_end_date,
  period_of_performance_potential_end_date,
  ordering_period_end_date,
  solicitation_date,
  awarding_agency_code,
  awarding_agency_name,
  awarding_sub_agency_code,
  awarding_sub_agency_name,
  awarding_office_code,
  awarding_office_name,
  funding_agency_code,
  funding_agency_name,
  funding_sub_agency_code,
  funding_sub_agency_name,
  funding_office_code,
  funding_office_name,
  treasury_accounts_funding_this_award,
  federal_accounts_funding_this_award,
  object_classes_funding_this_award,
  program_activities_funding_this_award,
  foreign_funding,
  foreign_funding_description,
  sam_exception,
  sam_exception_description,
  recipient_uei,
  recipient_duns,
  recipient_name,
  recipient_name_raw,
  recipient_doing_business_as_name,
  cage_code,
  recipient_parent_uei,
  recipient_parent_duns,
  recipient_parent_name,
  recipient_parent_name_raw,
  recipient_country_code,
  recipient_country_name,
  recipient_address_line_1,
  recipient_address_line_2,
  recipient_city_name,
  prime_award_transaction_recipient_county_fips_code,
  recipient_county_name,
  prime_award_transaction_recipient_state_fips_code,
  recipient_state_code,
  recipient_state_name,
  recipient_zip_4_code,
  prime_award_transaction_recipient_cd_original,
  prime_award_transaction_recipient_cd_current,
  recipient_phone_number,
  recipient_fax_number,
  primary_place_of_performance_country_code,
  primary_place_of_performance_country_name,
  primary_place_of_performance_city_name,
  prime_award_transaction_place_of_performance_county_fips_code,
  primary_place_of_performance_county_name,
  prime_award_transaction_place_of_performance_state_fips_code,
  primary_place_of_performance_state_code,
  primary_place_of_performance_state_name,
  primary_place_of_performance_zip_4,
  prime_award_transaction_place_of_performance_cd_original,
  prime_award_transaction_place_of_performance_cd_current,
  award_or_idv_flag,
  award_type_code,
  award_type,
  idv_type_code,
  idv_type,
  multiple_or_single_award_idv_code,
  multiple_or_single_award_idv,
  type_of_idc_code,
  type_of_idc,
  type_of_contract_pricing_code,
  type_of_contract_pricing,
  transaction_description,
  prime_award_base_transaction_description,
  action_type_code,
  action_type,
  solicitation_identifier,
  number_of_actions,
  inherently_governmental_functions,
  inherently_governmental_functions_description,
  product_or_service_code,
  product_or_service_code_description,
  contract_bundling_code,
  contract_bundling,
  dod_claimant_program_code,
  dod_claimant_program_description,
  naics_code,
  naics_description,
  recovered_materials_sustainability_code,
  recovered_materials_sustainability,
  domestic_or_foreign_entity_code,
  domestic_or_foreign_entity,
  dod_acquisition_program_code,
  dod_acquisition_program_description,
  information_technology_commercial_item_category_code,
  information_technology_commercial_item_category,
  epa_designated_product_code,
  epa_designated_product,
  country_of_product_or_service_origin_code,
  country_of_product_or_service_origin,
  place_of_manufacture_code,
  place_of_manufacture,
  subcontracting_plan_code,
  subcontracting_plan,
  extent_competed_code,
  extent_competed,
  solicitation_procedures_code,
  solicitation_procedures,
  type_of_set_aside_code,
  type_of_set_aside,
  evaluated_preference_code,
  evaluated_preference,
  research_code,
  research,
  fair_opportunity_limited_sources_code,
  fair_opportunity_limited_sources,
  other_than_full_and_open_competition_code,
  other_than_full_and_open_competition,
  number_of_offers_received,
  commercial_item_acquisition_procedures_code,
  commercial_item_acquisition_procedures,
  small_business_competitiveness_demonstration_program,
  simplified_procedures_for_certain_commercial_items_code,
  simplified_procedures_for_certain_commercial_items,
  a76_fair_act_action_code,
  a76_fair_act_action,
  fed_biz_opps_code,
  fed_biz_opps,
  local_area_set_aside_code,
  local_area_set_aside,
  price_evaluation_adjustment_preference_percent_difference,
  clinger_cohen_act_planning_code,
  clinger_cohen_act_planning,
  materials_supplies_articles_equipment_code,
  materials_supplies_articles_equipment,
  labor_standards_code,
  labor_standards,
  construction_wage_rate_requirements_code,
  construction_wage_rate_requirements,
  interagency_contracting_authority_code,
  interagency_contracting_authority,
  other_statutory_authority,
  program_acronym,
  parent_award_type_code,
  parent_award_type,
  parent_award_single_or_multiple_code,
  parent_award_single_or_multiple,
  major_program,
  national_interest_action_code,
  national_interest_action,
  cost_or_pricing_data_code,
  cost_or_pricing_data,
  cost_accounting_standards_clause_code,
  cost_accounting_standards_clause,
  government_furnished_property_code,
  government_furnished_property,
  sea_transportation_code,
  sea_transportation,
  undefinitized_action_code,
  undefinitized_action,
  consolidated_contract_code,
  consolidated_contract,
  performance_based_service_acquisition_code,
  performance_based_service_acquisition,
  multi_year_contract_code,
  multi_year_contract,
  contract_financing_code,
  contract_financing,
  purchase_card_as_payment_method_code,
  purchase_card_as_payment_method,
  contingency_humanitarian_or_peacekeeping_operation_code,
  contingency_humanitarian_or_peacekeeping_operation,
  alaskan_native_corporation_owned_firm,
  american_indian_owned_business,
  indian_tribe_federally_recognized,
  native_hawaiian_organization_owned_firm,
  tribally_owned_firm,
  veteran_owned_business,
  service_disabled_veteran_owned_business,
  woman_owned_business,
  women_owned_small_business,
  economically_disadvantaged_women_owned_small_business,
  joint_venture_women_owned_small_business,
  joint_venture_economic_disadvantaged_women_owned_small_bus,
  minority_owned_business,
  subcontinent_asian_asian_indian_american_owned_business,
  asian_pacific_american_owned_business,
  black_american_owned_business,
  hispanic_american_owned_business,
  native_american_owned_business,
  other_minority_owned_business,
  contracting_officers_determination_of_business_size,
  contracting_officers_determination_of_business_size_code,
  emerging_small_business,
  community_developed_corporation_owned_firm,
  labor_surplus_area_firm,
  us_federal_government,
  federally_funded_research_and_development_corp,
  federal_agency,
  us_state_government,
  us_local_government,
  city_local_government,
  county_local_government,
  inter_municipal_local_government,
  local_government_owned,
  municipality_local_government,
  school_district_local_government,
  township_local_government,
  us_tribal_government,
  foreign_government,
  organizational_type,
  corporate_entity_not_tax_exempt,
  corporate_entity_tax_exempt,
  partnership_or_limited_liability_partnership,
  sole_proprietorship,
  small_agricultural_cooperative,
  international_organization,
  us_government_entity,
  community_development_corporation,
  domestic_shelter,
  educational_institution,
  foundation,
  hospital_flag,
  manufacturer_of_goods,
  veterinary_hospital,
  hispanic_servicing_institution,
  receives_contracts,
  receives_financial_assistance,
  receives_contracts_and_financial_assistance,
  airport_authority,
  council_of_governments,
  housing_authorities_public_tribal,
  interstate_entity,
  planning_commission,
  port_authority,
  transit_authority,
  subchapter_scorporation,
  limited_liability_corporation,
  foreign_owned,
  for_profit_organization,
  nonprofit_organization,
  other_not_for_profit_organization,
  the_ability_one_program,
  private_university_or_college,
  state_controlled_institution_of_higher_learning,
  c_1862_land_grant_college,
  c_1890_land_grant_college,
  c_1994_land_grant_college,
  minority_institution,
  historically_black_college,
  tribal_college,
  alaskan_native_servicing_institution,
  native_hawaiian_servicing_institution,
  school_of_forestry,
  veterinary_college,
  dot_certified_disadvantage,
  self_certified_small_disadvantaged_business,
  small_disadvantaged_business,
  c8a_program_participant,
  historically_underutilized_business_zone_hubzone_firm,
  sba_certified_8a_joint_venture,
  highly_compensated_officer_1_name,
  highly_compensated_officer_1_amount,
  highly_compensated_officer_2_name,
  highly_compensated_officer_2_amount,
  highly_compensated_officer_3_name,
  highly_compensated_officer_3_amount,
  highly_compensated_officer_4_name,
  highly_compensated_officer_4_amount,
  highly_compensated_officer_5_name,
  highly_compensated_officer_5_amount,
  usaspending_permalink,
  initial_report_date,
  last_modified_date,
  _artifact_id,
  _row_num,
  _row_sha,
  _source_locator)
COMMENT 'Read-only. USAspending/FPDS prime transactions, N00024-09-C-2116 (construction prep).'
WITH SCHEMA COMPENSATION
AS SELECT * FROM users.xiaobing_shang1_civ.aircarrier_src_2116_contract_transactions
;

-- aircarrier_srcv_funding_history
CREATE VIEW xiaobing_shang1_civ.aircarrier_srcv_funding_history (
  whs_reference,
  https___www_esd_whs_mil_records_declass_foia_reading_room_reading_room_list_2_contracts,
  _artifact_id,
  _row_num,
  _row_sha,
  _source_locator)
COMMENT 'Read-only. Funding history source table.'
WITH SCHEMA COMPENSATION
AS SELECT * FROM users.xiaobing_shang1_civ.aircarrier_src_funding_history
;

-- aircarrier_srcv_jb_funding_tranche
CREATE VIEW xiaobing_shang1_civ.aircarrier_srcv_jb_funding_tranche (
  pb_year,
  hull,
  funding_fy,
  tranche_type,
  appropriation_fy,
  value_musd,
  scn_tas_derived,
  artifact_id,
  page,
  built_at)
COMMENT 'Read-only. J-book funding tranches with derived TAS.'
WITH SCHEMA COMPENSATION
AS SELECT * FROM users.xiaobing_shang1_civ.aircarrier_jb_funding_tranche
;

-- aircarrier_srcv_jb_ship_cost
CREATE VIEW xiaobing_shang1_civ.aircarrier_srcv_jb_ship_cost (
  pb_year,
  artifact_id,
  page,
  hull,
  hull_printed,
  funding_fy,
  row_label,
  category,
  tranche_fy,
  printed,
  qty,
  unit,
  unit_inferred,
  value_musd,
  net_p1_ties,
  categories_tie,
  extractor,
  built_at)
COMMENT 'Read-only. J-book P-5/P-5c ship cost cells, PB2008-PB2027.'
WITH SCHEMA COMPENSATION
AS SELECT * FROM users.xiaobing_shang1_civ.aircarrier_jb_ship_cost
;

-- aircarrier_srcv_pdf_pages
CREATE VIEW xiaobing_shang1_civ.aircarrier_srcv_pdf_pages (
  artifact_id,
  filename,
  page,
  text,
  chars,
  n_tables,
  n_text_tables,
  legends,
  exhibits,
  grade,
  zone,
  built_at)
COMMENT 'Read-only. Page text of every registered PDF (document_text tool).'
WITH SCHEMA COMPENSATION
AS SELECT * FROM users.xiaobing_shang1_civ.aircarrier_pdf_pages
;

-- aircarrier_srcv_subawards_2114
CREATE VIEW xiaobing_shang1_civ.aircarrier_srcv_subawards_2114 (
  prime_award_unique_key,
  prime_award_piid,
  prime_award_parent_piid,
  prime_award_amount,
  prime_award_disaster_emergency_fund_codes,
  prime_award_outlayed_amount_from_covid_19_supplementals,
  prime_award_obligated_amount_from_covid_19_supplementals,
  prime_award_outlayed_amount_from_iija_supplemental,
  prime_award_obligated_amount_from_iija_supplemental,
  prime_award_total_outlayed_amount,
  prime_award_base_action_date,
  prime_award_base_action_date_fiscal_year,
  prime_award_latest_action_date,
  prime_award_latest_action_date_fiscal_year,
  prime_award_period_of_performance_start_date,
  prime_award_period_of_performance_current_end_date,
  prime_award_period_of_performance_potential_end_date,
  prime_award_awarding_agency_code,
  prime_award_awarding_agency_name,
  prime_award_awarding_sub_agency_code,
  prime_award_awarding_sub_agency_name,
  prime_award_awarding_office_code,
  prime_award_awarding_office_name,
  prime_award_funding_agency_code,
  prime_award_funding_agency_name,
  prime_award_funding_sub_agency_code,
  prime_award_funding_sub_agency_name,
  prime_award_funding_office_code,
  prime_award_funding_office_name,
  prime_award_treasury_accounts_funding_this_award,
  prime_award_federal_accounts_funding_this_award,
  prime_award_object_classes_funding_this_award,
  prime_award_program_activities_funding_this_award,
  prime_awardee_uei,
  prime_awardee_duns,
  prime_awardee_name,
  prime_awardee_dba_name,
  prime_awardee_parent_uei,
  prime_awardee_parent_duns,
  prime_awardee_parent_name,
  prime_awardee_country_code,
  prime_awardee_country_name,
  prime_awardee_address_line_1,
  prime_awardee_city_name,
  prime_awardee_county_fips_code,
  prime_awardee_county_name,
  prime_awardee_state_fips_code,
  prime_awardee_state_code,
  prime_awardee_state_name,
  prime_awardee_zip_code,
  prime_award_summary_recipient_cd_original,
  prime_award_summary_recipient_cd_current,
  prime_awardee_foreign_postal_code,
  prime_awardee_business_types,
  prime_award_primary_place_of_performance_city_name,
  prime_award_primary_place_of_performance_county_fips_code,
  prime_award_primary_place_of_performance_county_name,
  prime_award_primary_place_of_performance_state_fips_code,
  prime_award_primary_place_of_performance_state_code,
  prime_award_primary_place_of_performance_state_name,
  prime_award_primary_place_of_performance_address_zip_code,
  prime_award_summary_place_of_performance_cd_original,
  prime_award_summary_place_of_performance_cd_current,
  prime_award_primary_place_of_performance_country_code,
  prime_award_primary_place_of_performance_country_name,
  prime_award_base_transaction_description,
  prime_award_project_title,
  prime_award_naics_code,
  prime_award_naics_description,
  prime_award_national_interest_action_code,
  prime_award_national_interest_action,
  subaward_type,
  subaward_sam_report_id,
  subaward_sam_report_year,
  subaward_sam_report_month,
  subaward_number,
  subaward_amount,
  subaward_action_date,
  subaward_action_date_fiscal_year,
  subawardee_uei,
  subawardee_duns,
  subawardee_name,
  subawardee_dba_name,
  subawardee_parent_uei,
  subawardee_parent_duns,
  subawardee_parent_name,
  subawardee_country_code,
  subawardee_country_name,
  subawardee_address_line_1,
  subawardee_city_name,
  subawardee_state_code,
  subawardee_state_name,
  subawardee_zip_code,
  subaward_recipient_cd_original,
  subaward_recipient_cd_current,
  subawardee_foreign_postal_code,
  subawardee_business_types,
  subaward_primary_place_of_performance_city_name,
  subaward_primary_place_of_performance_state_code,
  subaward_primary_place_of_performance_state_name,
  subaward_primary_place_of_performance_address_zip_code,
  subaward_place_of_performance_cd_original,
  subaward_place_of_performance_cd_current,
  subaward_primary_place_of_performance_country_code,
  subaward_primary_place_of_performance_country_name,
  subaward_description,
  subawardee_highly_compensated_officer_1_name,
  subawardee_highly_compensated_officer_1_amount,
  subawardee_highly_compensated_officer_2_name,
  subawardee_highly_compensated_officer_2_amount,
  subawardee_highly_compensated_officer_3_name,
  subawardee_highly_compensated_officer_3_amount,
  subawardee_highly_compensated_officer_4_name,
  subawardee_highly_compensated_officer_4_amount,
  subawardee_highly_compensated_officer_5_name,
  subawardee_highly_compensated_officer_5_amount,
  usaspending_permalink,
  subaward_sam_report_last_modified_date,
  _artifact_id,
  _row_num,
  _row_sha,
  _source_locator)
COMMENT 'Read-only. USAspending sub-awards, 15-C-2114.'
WITH SCHEMA COMPENSATION
AS SELECT * FROM users.xiaobing_shang1_civ.aircarrier_src_2114_subawards
;

-- aircarrier_v_doc_anchor_chain
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_anchor_chain (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document anchor_chain for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'anchor_chain'
;

-- aircarrier_v_doc_asset
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_asset (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document asset for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'asset'
;

-- aircarrier_v_doc_attribution
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_attribution (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document attribution for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'attribution'
;

-- aircarrier_v_doc_cap_history
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_cap_history (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document cap_history for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'cap_history'
;

-- aircarrier_v_doc_clue_map
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_clue_map (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document clue_map for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'clue_map'
;

-- aircarrier_v_doc_contracts
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_contracts (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document contracts for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'contracts'
;

-- aircarrier_v_doc_corpus
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_corpus (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document corpus for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'corpus'
;

-- aircarrier_v_doc_cost_categories
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_cost_categories (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document cost_categories for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'cost_categories'
;

-- aircarrier_v_doc_delivery
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_delivery (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document delivery for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'delivery'
;

-- aircarrier_v_doc_equipment
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_equipment (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document equipment for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'equipment'
;

-- aircarrier_v_doc_estimate_history
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_estimate_history (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document estimate_history for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'estimate_history'
;

-- aircarrier_v_doc_federal_accounts
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_federal_accounts (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document federal_accounts for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'federal_accounts'
;

-- aircarrier_v_doc_funding_streams
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_funding_streams (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document funding_streams for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'funding_streams'
;

-- aircarrier_v_doc_gaps
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_gaps (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document gaps for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'gaps'
;

-- aircarrier_v_doc_industrial
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_industrial (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document industrial for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'industrial'
;

-- aircarrier_v_doc_layers
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_layers (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document layers for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'layers'
;

-- aircarrier_v_doc_obligations
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_obligations (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document obligations for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'obligations'
;

-- aircarrier_v_doc_program
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_program (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document program for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'program'
;

-- aircarrier_v_doc_rules
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_rules (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document rules for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'rules'
;

-- aircarrier_v_doc_sources
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_sources (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document sources for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'sources'
;

-- aircarrier_v_doc_subawards
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_subawards (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document subawards for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'subawards'
;

-- aircarrier_v_doc_timeline
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_timeline (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document timeline for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'timeline'
;

-- aircarrier_v_doc_variances
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_doc_variances (
  doc,
  content_sha,
  built_at)
COMMENT 'Page document variances for the app uc backend (etl/publish_serving_docs.py).'
WITH SCHEMA COMPENSATION
AS SELECT doc, content_sha, built_at FROM users.xiaobing_shang1_civ.aircarrier_serving_doc WHERE name = 'variances'
;

-- aircarrier_v_gaps
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_gaps (
  id,
  title,
  status,
  type,
  executor,
  exposure_usd_m,
  ignorance,
  closability,
  decay,
  note,
  closed,
  priority,
  _source,
  _published_at)
WITH SCHEMA COMPENSATION
AS SELECT * FROM users.xiaobing_shang1_civ.aircarrier_gaps
;

-- aircarrier_v_review_queue
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_review_queue (
  claim_id,
  hull,
  layer,
  element,
  period,
  value,
  unit,
  exposure_share,
  rule,
  reason,
  flags,
  tells,
  artifact_id,
  exhibit,
  page,
  row_label,
  column_header_chain,
  source_system,
  gated_at)
COMMENT 'Human review queue (gate.yaml review_queue): claim, flag, the specific tell, what it bears on, ranked by exposure.'
WITH SCHEMA COMPENSATION
AS SELECT g.claim_id, l.hull, l.layer, l.element, l.period, l.value, l.unit, g.exposure_share,
    g.rule, g.reason, g.flags, g.tells, l.coordinate.artifact_id, l.coordinate.exhibit, l.coordinate.page,
    l.coordinate.row_label, l.coordinate.column_header_chain, l.source_system, g.gated_at
  FROM users.xiaobing_shang1_civ.aircarrier_gate g JOIN users.xiaobing_shang1_civ.aircarrier_claim l ON l.claim_id = g.claim_id AND l.version_sha = g.version_sha
  WHERE g.outcome = 'human_review' AND l.superseded_by IS NULL
  ORDER BY g.exposure_share DESC
;

-- aircarrier_v_variances
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_variances (
  id,
  status,
  flag,
  title,
  detail,
  _source,
  _published_at)
WITH SCHEMA COMPENSATION
AS SELECT * FROM users.xiaobing_shang1_civ.aircarrier_variances
;

-- aircarrier_v_work_queue
CREATE VIEW xiaobing_shang1_civ.aircarrier_v_work_queue (
  id,
  title,
  status,
  closability,
  executor,
  priority,
  exposure_usd_m,
  ignorance,
  free_now,
  queue_rank)
COMMENT 'Open gaps ranked for work: register priority, then exposure. Read-only queue for agents.'
WITH SCHEMA COMPENSATION
AS SELECT id, title, status, closability, executor, CAST(priority AS DOUBLE) AS priority,
          CAST(exposure_usd_m AS DOUBLE) AS exposure_usd_m, CAST(ignorance AS DOUBLE) AS ignorance,
          closability IN ('zero_access', 'query') AS free_now,
          row_number() OVER (ORDER BY CAST(priority AS DOUBLE) DESC, CAST(exposure_usd_m AS DOUBLE) DESC, id) AS queue_rank
FROM users.xiaobing_shang1_civ.aircarrier_gaps
WHERE NOT CAST(closed AS BOOLEAN)
;

-- mcp_a_creator_trace_metadata
CREATE VIEW xiaobing_shang1_civ.mcp_a_creator_trace_metadata (
  trace_id,
  client_request_id,
  tags,
  trace_metadata,
  assessments)
WITH SCHEMA BINDING
AS WITH
-- 1. Extract trace metadata from annotations table (handling duplicates by taking the most recent)
trace_metadata AS (
  SELECT
    trace_id,
    metadata_data
  FROM (
    SELECT
      target_id AS trace_id,
      value AS metadata_data,
      ROW_NUMBER() OVER (
        PARTITION BY target_id
        ORDER BY updated_at DESC
      ) AS rn
    FROM
      `users`.`xiaobing_shang1_civ`.`mcp_a_creator_otel_annotations`
    WHERE
      annotation_type = 'METADATA'
  )
  WHERE rn = 1
),
-- 2. Extract and aggregate individual tag annotations (handling duplicates by taking the most recent)
tags_agg AS (
  SELECT
    trace_id,
    MAP_FROM_ENTRIES(
      COLLECT_LIST(
        STRUCT(
          key,
          value
        )
      )
    ) AS tags
  FROM (
    SELECT
      target_id AS trace_id,
      name AS key,
      value::STRING AS value,
      ROW_NUMBER() OVER (
        PARTITION BY target_id, name
        ORDER BY updated_at DESC
      ) AS rn,
      deleted_at
    FROM
      `users`.`xiaobing_shang1_civ`.`mcp_a_creator_otel_annotations`
    WHERE
      annotation_type = 'TAG'
  )
  WHERE rn = 1 AND deleted_at IS NULL
  GROUP BY
    trace_id
),
-- 3. Aggregated valid assessments from annotations table grouped by trace_id
assessments_agg AS (
  SELECT
    trace_id,
    COLLECT_LIST(
      STRUCT(
        annotation_id,
        annotation_type,
        name,
        value,
        comment,
        metadata,
        created_at,
        updated_at
      )
    ) AS assessments
  FROM
    (
    SELECT
      target_id AS trace_id,
      annotation_id,
      annotation_type,
      name,
      value,
      comment,
      metadata,
      created_at,
      updated_at,
      deleted_at,
      ROW_NUMBER() OVER (
        PARTITION BY annotation_id
        ORDER BY updated_at DESC
      ) AS rn
    FROM
      `users`.`xiaobing_shang1_civ`.`mcp_a_creator_otel_annotations`
    WHERE
      annotation_type IN ('FEEDBACK', 'EXPECTATION', 'ISSUE')
    )
  WHERE
    rn = 1 AND deleted_at IS NULL
  GROUP BY
    trace_id
)
-- 4. Main query - join metadata with tags and assessments
SELECT
  tm.trace_id,
  tm.metadata_data:client_request_id::STRING AS client_request_id,
  COALESCE(ta.tags, MAP()) AS tags,
  tm.metadata_data:trace_metadata AS trace_metadata,
  COALESCE(
    TRANSFORM(
      aa.assessments,
      a -> STRUCT(
        a.annotation_id AS assessment_id,
        tm.trace_id AS trace_id,
        a.name AS assessment_name,
        STRUCT(
          a.metadata:['mlflow.source.source_id']::STRING AS source_id,
          a.metadata:['mlflow.source.source_type']::STRING AS source_type
        ) AS source,
        a.created_at AS create_time,
        a.updated_at AS last_update_time,
        CASE
          WHEN a.annotation_type = 'EXPECTATION' THEN
            STRUCT(
              CASE
                WHEN a.metadata:['mlflow.expectation.serialization_format']::STRING IS NOT NULL
                THEN NULL
                ELSE a.value::STRING
              END AS value,
              CASE
                WHEN a.metadata:['mlflow.expectation.serialization_format']::STRING IS NOT NULL
                THEN STRUCT(
                  a.metadata:['mlflow.expectation.serialization_format']::STRING AS serialization_format,
                  a.value::STRING AS value,
                  CAST(NULL AS STRING) AS stack_trace
                )
                ELSE NULL
              END AS serialized_value
            )
          ELSE NULL
        END AS expectation,
        CASE
          WHEN a.annotation_type = 'FEEDBACK' THEN
            STRUCT(
              a.value::STRING AS value,
              CASE
                WHEN a.metadata:['mlflow.error.error_code']::STRING IS NOT NULL
                  OR a.metadata:['mlflow.error.error_message']::STRING IS NOT NULL
                  OR a.metadata:['mlflow.error.stack_trace']::STRING IS NOT NULL
                THEN STRUCT(
                  a.metadata:['mlflow.error.error_code']::STRING AS error_code,
                  a.metadata:['mlflow.error.error_message']::STRING AS error_message,
                  a.metadata:['mlflow.error.stack_trace']::STRING AS stack_trace
                )
                ELSE NULL
              END AS error
            )
          ELSE NULL
        END AS feedback,
        CASE
          WHEN a.annotation_type = 'ISSUE' THEN
            STRUCT(a.value::STRING AS issue_name)
          ELSE NULL
        END AS issue,
        a.comment AS rationale,
        a.metadata::MAP<STRING, STRING> AS metadata,
        a.metadata:['mlflow.span_id']::STRING AS span_id,
        a.metadata:['mlflow.overrides']::STRING AS overrides,
        a.metadata:['mlflow.valid']::STRING AS valid
      )
    ),
    ARRAY()
  ) AS assessments
FROM
  trace_metadata tm
  LEFT JOIN tags_agg ta ON tm.trace_id = ta.trace_id
  LEFT JOIN assessments_agg aa ON tm.trace_id = aa.trace_id

;

-- mcp_a_creator_trace_unified
CREATE VIEW xiaobing_shang1_civ.mcp_a_creator_trace_unified (
  trace_id,
  client_request_id,
  request_time,
  state,
  execution_duration_ms,
  request,
  response,
  trace_metadata,
  tags,
  spans,
  assessments)
WITH SCHEMA BINDING
AS WITH
-- 1. Extract trace metadata from annotations table (handling duplicates by taking the most recent)
trace_metadata AS (
  SELECT
    trace_id,
    metadata_data
  FROM (
    SELECT
      target_id AS trace_id,
      value AS metadata_data,
      ROW_NUMBER() OVER (
        PARTITION BY target_id
        ORDER BY updated_at DESC
      ) AS rn
    FROM
      `users`.`xiaobing_shang1_civ`.`mcp_a_creator_otel_annotations`
    WHERE
      annotation_type = 'METADATA'
  )
  WHERE rn = 1
),
-- 2. Extract and aggregate individual tag annotations (handling duplicates by taking the most recent)
tags_agg AS (
  SELECT
    trace_id,
    MAP_FROM_ENTRIES(
      COLLECT_LIST(
        STRUCT(
          key,
          value
        )
      )
    ) AS tags
  FROM (
    SELECT
      target_id AS trace_id,
      name AS key,
      value::STRING AS value,
      ROW_NUMBER() OVER (
        PARTITION BY target_id, name
        ORDER BY updated_at DESC
      ) AS rn,
      deleted_at
    FROM
      `users`.`xiaobing_shang1_civ`.`mcp_a_creator_otel_annotations`
    WHERE
      annotation_type = 'TAG'
  )
  WHERE rn = 1 AND deleted_at IS NULL
  GROUP BY
    trace_id
),
-- 3. Extract the root span which contains the full request/response and trace-level info (handling duplicates by taking the most recent)
root_span AS (
  SELECT
    trace_id,
    span_id,
    name,
    request_time,
    state,
    execution_duration_ms,
    request,
    response
  FROM (
    SELECT
      trace_id,
      span_id,
      name,
      time AS request_time,
      CASE
        WHEN status.code = 'STATUS_CODE_OK' OR status.code IS NULL THEN 'OK' -- Convert from OTEL status code semantics to the MLflow status code
        WHEN status.code = 'STATUS_CODE_ERROR' THEN 'ERROR'
        ELSE status.code
      END AS state,
      (end_time_unix_nano / 1000000.0 - UNIX_MILLIS(time)) AS execution_duration_ms,
      COALESCE(
      attributes:['mlflow.spanInputs']::string,
      attributes:['gen_ai.input.messages']::string,
      attributes:['gen_ai.tool.call.arguments']::string,
      attributes:['input.value']::string,
      attributes:['traceloop.entity.input']::string,
      attributes:['gcp.vertex.agent.llm_request']::string,
      attributes:['gcp.vertex.agent.tool_call_args']::string
    ) AS request,
      COALESCE(
      attributes:['mlflow.spanOutputs']::string,
      attributes:['gen_ai.output.messages']::string,
      attributes:['gen_ai.tool.call.result']::string,
      attributes:['output.value']::string,
      attributes:['traceloop.entity.output']::string,
      attributes:['gcp.vertex.agent.llm_response']::string,
      attributes:['gcp.vertex.agent.tool_response']::string
    ) AS response,
      ROW_NUMBER() OVER (
        PARTITION BY trace_id
        ORDER BY time DESC
      ) AS rn
    FROM
      `users`.`xiaobing_shang1_civ`.`mcp_a_creator_otel_spans`
    WHERE
      COALESCE(parent_span_id, "") = ""  -- Root span has empty parent
  )
  WHERE rn = 1
),
-- 4. Aggregate all spans grouped by trace_id
spans_agg AS (
  SELECT
    trace_id,
    COLLECT_LIST(STRUCT(*)) AS spans
  FROM
    `users`.`xiaobing_shang1_civ`.`mcp_a_creator_otel_spans`
  GROUP BY
    trace_id
),
-- 5. Aggregated valid assessments from annotations table grouped by trace_id
assessments_agg AS (
  SELECT
    trace_id,
    COLLECT_LIST(
      STRUCT(
        annotation_id,
        annotation_type,
        name,
        value,
        comment,
        metadata,
        created_at,
        updated_at
      )
    ) AS assessments
  FROM
    (
    SELECT
      target_id AS trace_id,
      annotation_id,
      annotation_type,
      name,
      value,
      comment,
      metadata,
      created_at,
      updated_at,
      deleted_at,
      ROW_NUMBER() OVER (
        PARTITION BY annotation_id
        ORDER BY updated_at DESC
      ) AS rn
    FROM
      `users`.`xiaobing_shang1_civ`.`mcp_a_creator_otel_annotations`
    WHERE
      annotation_type IN ('FEEDBACK', 'EXPECTATION', 'ISSUE')
    )
  WHERE
    rn = 1 AND deleted_at IS NULL
  GROUP BY
    trace_id
)
-- 6. Main query - join the trace data from spans with metadata, tags, and assessments
SELECT
  rs.trace_id,
  tm.metadata_data:client_request_id::STRING AS client_request_id,
  rs.request_time,
  rs.state,
  rs.execution_duration_ms,
  rs.request,
  rs.response,
  tm.metadata_data:trace_metadata AS trace_metadata,
  COALESCE(ta.tags, MAP()) AS tags,
  sa.spans,
  COALESCE(
    TRANSFORM(
      aa.assessments,
      a -> STRUCT(
        a.annotation_id AS assessment_id,
        rs.trace_id AS trace_id,
        a.name AS assessment_name,
        STRUCT(
          a.metadata:['mlflow.source.source_id']::STRING AS source_id,
          a.metadata:['mlflow.source.source_type']::STRING AS source_type
        ) AS source,
        a.created_at AS create_time,
        a.updated_at AS last_update_time,
        CASE
          WHEN a.annotation_type = 'EXPECTATION' THEN
            STRUCT(
              CASE
                WHEN a.metadata:['mlflow.expectation.serialization_format']::STRING IS NOT NULL
                THEN NULL
                ELSE a.value::STRING
              END AS value,
              CASE
                WHEN a.metadata:['mlflow.expectation.serialization_format']::STRING IS NOT NULL
                THEN STRUCT(
                  a.metadata:['mlflow.expectation.serialization_format']::STRING AS serialization_format,
                  a.value::STRING AS value,
                  CAST(NULL AS STRING) AS stack_trace
                )
                ELSE NULL
              END AS serialized_value
            )
          ELSE NULL
        END AS expectation,
        CASE
          WHEN a.annotation_type = 'FEEDBACK' THEN
            STRUCT(
              a.value::STRING AS value,
              CASE
                WHEN a.metadata:['mlflow.error.error_code']::STRING IS NOT NULL
                  OR a.metadata:['mlflow.error.error_message']::STRING IS NOT NULL
                  OR a.metadata:['mlflow.error.stack_trace']::STRING IS NOT NULL
                THEN STRUCT(
                  a.metadata:['mlflow.error.error_code']::STRING AS error_code,
                  a.metadata:['mlflow.error.error_message']::STRING AS error_message,
                  a.metadata:['mlflow.error.stack_trace']::STRING AS stack_trace
                )
                ELSE NULL
              END AS error
            )
          ELSE NULL
        END AS feedback,
        CASE
          WHEN a.annotation_type = 'ISSUE' THEN
            STRUCT(a.value::STRING AS issue_name)
          ELSE NULL
        END AS issue,
        a.comment AS rationale,
        a.metadata::MAP<STRING, STRING> AS metadata,
        a.metadata:['mlflow.span_id']::STRING AS span_id,
        a.metadata:['mlflow.overrides']::STRING AS overrides,
        a.metadata:['mlflow.valid']::STRING AS valid
      )
    ),
    ARRAY()
  ) AS assessments
FROM
  root_span rs
  LEFT JOIN trace_metadata tm ON rs.trace_id = tm.trace_id
  LEFT JOIN tags_agg ta ON rs.trace_id = ta.trace_id
  LEFT JOIN assessments_agg aa ON rs.trace_id = aa.trace_id
  LEFT JOIN spans_agg sa ON rs.trace_id = sa.trace_id

;
