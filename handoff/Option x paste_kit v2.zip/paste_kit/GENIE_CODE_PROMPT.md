# Air Carrier — Genie Code build prompt for Advana FM

Paste everything below this line into Genie Code in a single message.

---

I am building the Air Carrier CVN-79 cost reconciliation system in this workspace from a paste kit that was transferred from a commercial Databricks workspace. The paste kit is already here — the notebook cells have been pasted and the app zip has been uploaded. I need you to run the build, handle anything that goes wrong due to environment differences, and verify the result.

## What is already done

1. A notebook called "Air Carrier Paste Kit" exists in my workspace with these cells already pasted:
   - **Cell 1** (setup): defines CATALOG, SCHEMA, CODE_DIR, NAME_PREFIX and the chunk-staging helpers
   - **Cell 2** was used to paste all 46 chunks (code, core data, pdf data). They are saved in the staging directory.
   - **Cell 3** (build): creates 77 tables, 36 views, 8 functions, 18 CHECK constraints, and loads 2,005,448 rows
   - **Cell 4** (app deploy): extracts the app zip, creates the Databricks App, sets 15 env vars, deploys
   - **Cell 5** (grants): gives the app's service principal SELECT on the v_doc views and operational tables
   - **Cell 6** (test): smoke-tests the app and data layer

2. `aircarrier_app.zip` (6.37 MB, 125 files) has been uploaded to my workspace.

## What I need you to do

### Phase 1: Environment detection (do this FIRST, before running anything)

Run a single cell that detects and prints:

```python
import importlib.metadata, sys, os
print(f"Python: {sys.version}")
try: print(f"DBR: {os.environ.get('DATABRICKS_RUNTIME_VERSION', 'unknown')}")
except: pass
try: print(f"SDK: {importlib.metadata.version('databricks-sdk')}")
except: print("SDK: not found")
try:
    r = spark.sql("SELECT current_catalog(), current_schema(), current_user()").first()
    print(f"Catalog: {r[0]}, Schema: {r[1]}, User: {r[2]}")
except Exception as e: print(f"Catalog check: {e}")
# Check if Databricks Apps is available
try:
    from databricks.sdk import WorkspaceClient
    w = WorkspaceClient()
    apps = list(w.apps.list())
    print(f"Apps API: available ({len(apps)} existing apps)")
except Exception as e:
    print(f"Apps API: {str(e)[:200]}")
# Check available model serving endpoints
try:
    eps = [ep.name for ep in w.serving_endpoints.list()]
    print(f"Serving endpoints ({len(eps)}): {eps[:20]}")
except Exception as e:
    print(f"Endpoints: {str(e)[:200]}")
# Check runtime SQL compatibility
for test_sql, label in [
    ("SELECT CAST(MAP('a','1') AS MAP<STRING,STRING>)", "MAP type"),
    ("SELECT ARRAY(1,2,3)", "ARRAY type"),
    ("SELECT to_json(named_struct('x', 1))", "to_json"),
]:
    try: spark.sql(test_sql).first(); print(f"SQL: {label} OK")
    except Exception as e: print(f"SQL: {label} FAIL - {str(e).splitlines()[0][:100]}")
```

Report the results before proceeding. I need to see them.

### Phase 2: Run Cell 1 (setup) and Cell 3 (build)

Run Cell 1, then Cell 3. Cell 3 builds everything and verifies it. Wait for `RESULT: ALL CHECKS PASSED`.

**If something fails in Cell 3**, here is what to expect and how to handle it:

- **`WITH SCHEMA COMPENSATION` fails on views**: Cell 3 already retries without it. If a view still fails, show me the error — it is likely a missing table dependency.
- **CHECK constraint fails**: The 16 complex constraints use `size()`, `length()`, `trim()`, and `IN ()`. These work on DBR 10.4+. If your runtime is older, skip the constraint (comment out the ALTER TABLE line) and note it.
- **`to_json` in a function fails**: Functions 1-3 use `to_json`. If it fails, your runtime may need `CAST(... AS STRING)` instead. Show me the error.
- **A table creation fails with an unknown type**: All column types are standard (string, int, timestamp, array, double, bigint, boolean, map, decimal, struct). If one fails, show me which table and column.
- **The INSERT INTO fails with a schema mismatch**: Cell 3 casts every column from the parquet to the target table's schema. If a CAST fails, the parquet may have a timestamp precision difference. Try: `spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")`

### Phase 3: App deployment (choose the right path)

Based on the Phase 1 results, choose ONE:

#### Path A: Direct deploy (Apps API is available)

Run Cell 4. But first, edit these values:
- `APP_ZIP_PATH`: the full `/Workspace/...` path to the uploaded zip
- `WAREHOUSE_ID`: from the SQL Warehouses page (click a warehouse, copy its ID)
- `DRAGON_MODE = False`
- Model endpoints: change to whatever endpoints the Phase 1 detection showed

Cell 4 handles SDK version differences (tries `EnvVar`, then `EnvVariable`, then `AppEnvironmentVariable`).

If it fails with a permissions error on `apps.create`, you may not have app-creation rights. Ask your workspace admin.

#### Path B: Dragon pipeline (Apps API blocked or requires GitLab CI/CD)

Set `DRAGON_MODE = True` in Cell 4 and run it. It will:
1. Extract the 125 app files into `CODE_DIR/app/`
2. Print the 15 env vars you need
3. NOT attempt to create or deploy the app

Then:
1. Push `CODE_DIR/app/` to your Advana GitLab repository
2. Configure the Dragon CI/CD pipeline to deploy it as a Databricks App
3. Set the 15 env vars in the pipeline config or the app's `app.yaml` under `config.env`
4. The pipeline runs `databricks bundle deploy` against an accredited target

The app is self-contained: `app/` has no imports outside itself. The `_ops/ops/ingest/search.py` module is vendored inside the app. The `requirements.txt` pins: fastapi==0.115.6, uvicorn[standard]==0.34.0, jinja2==3.1.5, databricks-sdk==0.40.0, pyyaml==6.0.2.

If PyPI is unreachable at build time (IL5 egress restrictions), the wheels must be vendored. The Dragon pipeline's base image may already include them.

#### Path C: No app at all (Databricks Apps not enabled)

Skip Cells 4-6. You still have:
- All 77 tables with 2M+ rows of data
- 36 views (the 23 v_doc_* views the app reads, plus 13 analytical views)
- 8 SQL functions (the tool-calling functions the agent uses)
- 3 Genie Code skills (aircarrier-investigate, aircarrier-verify-figure, aircarrier-collection-request)

You can query everything directly. Example:
```sql
SELECT COUNT(*), SUM(CAST(federal_action_obligation AS DECIMAL(20,2)))
FROM <catalog>.<schema>.aircarrier_src_2116_contract_transactions;
-- Expected: 948 rows, 4519300323.83
```

The skills are already installed. Try: "Use the aircarrier-investigate skill to work gap G1."

### Phase 4: Grants and test (if app was deployed)

Run Cell 5 (grants), then Cell 6 (test). Cell 6 checks:
- App status is RUNNING
- App URL is reachable
- v_doc views are queryable
- Known answer still matches
- Env vars are set on the deployment

### Phase 5: Report

After all phases, give me a summary:
1. Environment: DBR version, SDK version, Apps available (yes/no)
2. Data layer: how many tables/views/functions created, any failures
3. Known answers: PASS or FAIL with the actual numbers
4. App: deployed (URL) / prepared for Dragon / skipped
5. Any items that need manual follow-up

## Known environment risks (read before starting)

| Risk | What happens | Mitigation |
|---|---|---|
| Model endpoints have different names on IL5 | Cell 4 config points to wrong endpoints | Phase 1 detects available endpoints; edit Cell 4 before running |
| `WITH SCHEMA COMPENSATION` not supported | View creation fails | Cell 3 already retries without it |
| Databricks Apps not enabled | Cell 4 fails | Use Path B (Dragon) or Path C (no app) |
| PyPI unreachable | App build fails at deploy | Vendor wheels or use Dragon base image |
| Older SDK (< 0.40) | Import errors in Cell 4 | Cell 4 tries 3 different class names |
| DBR < 10.4 | Some CHECK constraints may fail | Skip constraints, note which ones |
| `federal_action_obligation` is STRING | SUM without CAST returns NULL | All verification SQL uses CAST(... AS DECIMAL(20,2)) |
| Dragon pipeline required for apps | Direct deploy blocked | Set DRAGON_MODE = True in Cell 4 |
| Different egress rules | App can't reach PyPI | Dependencies are pinned in requirements.txt; vendor if needed |

## Key facts

- Source workspace: `dbc-aae0ba16-8727` (commercial), owner `xiaobing.shang1.civ@mail.mil`
- 77 Air Carrier tables, 36 views, 8 functions, 18 CHECK constraints
- 2,005,448 rows across all tables (src, pdf, kg, work, app, serving)
- Known answers: contract 2116 = 948 rows / $4,519,300,323.83; contract 2114 = 927 rows / $4,578,603,345.77
- The `federal_action_obligation` column is STRING type — always use `CAST(... AS DECIMAL(20,2))` for sums
- 3 Genie Code skills installed: aircarrier-investigate, aircarrier-verify-figure, aircarrier-collection-request
- App reads from 23 `v_doc_*` views via `DATA_BACKEND=uc`; falls back to shipped `app/data/*.json` if views fail
- seed/models.yaml is the source of truth for model routing
